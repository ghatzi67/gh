package com.workable.movie.app.utils;

/**
 * This is a simple wrapper exception class.
 *
 * @see java.lang.Exception
 */
@SuppressWarnings("serial")
public class CUSTException extends Exception {

	/**
	 * Constructs a new exception with null as its detail message.
	 */
	public CUSTException() {
	}

	/**
	 * Constructs a new exception with the specified detail message.
	 *
	 * @param err The detail message.
	 */
	public CUSTException(String err) {
		super(err);
	}

	/**
	 * Constructs a new exception with the specified cause.
	 *
	 * @param cause The cause.
	 */
	public CUSTException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructs a new exception with the specified detail message and cause.
	 *
	 * @param err   The detail message.
	 * @param cause The cause.
	 */
	public CUSTException(String err, Throwable cause) {
		super(err, cause);
	}
}
