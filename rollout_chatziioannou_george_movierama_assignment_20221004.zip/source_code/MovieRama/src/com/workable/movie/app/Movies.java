package com.workable.movie.app;

import com.workable.movie.app.utils.CUSTConnection;
import com.workable.movie.app.utils.PropUtilsCust;
import com.workable.movie.app.utils.XMLUtils;
import com.workable.movie.app.utils.XSUUtils;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLNode;

public class Movies {
	private static Logger logger = Logger.getLogger(Movies.class);
	private String html;
	private int orderCol = 1;
	private String user = "";
	
	private String movieTitle;
	private String movieDescription;
	private String movieUser;
	
	public Movies() {
	    PropertyConfigurator.configure( PropUtilsCust.getResource("LogPath") );
	}
	
	public XMLNode getResult() throws Exception {
		String sql = null;
		Connection cn1 = null;
	    XMLDocument xml = null;
		
		try{
			cn1 = new CUSTConnection().GetNewConn();
			sql = 
			"SELECT A.MOVIE_ID,\n" +
			"		A.MOVIE_USER,\n" + 
			"		A.MOVIE_TITLE,\n" + 
			"		A.MOVIE_DESCRIPTION,\n" + 
			"		TO_CHAR(A.MOVIE_PUBLISH_DATE, 'DD/MM/YYYY HH24:MI:SS') AS MOVIE_PUBLISH_DATE,\n" + 
		    "       (SELECT COUNT(*) FROM MOVIES_VOTES B WHERE B.MOVIE_ID=A.MOVIE_ID AND VOTE=1) AS NUM_OF_LIKES,\n" + 
		    "       (SELECT COUNT(*) FROM MOVIES_VOTES B WHERE B.MOVIE_ID=A.MOVIE_ID AND VOTE=2) AS NUM_OF_HATES,\n" +
			"		TRUNC(SYSDATE)-TRUNC(A.MOVIE_PUBLISH_DATE) AS DATE_DIF\n" + 
			"  FROM MOVIES A" +
			" WHERE 1=1";
			if(!"".equals(user) && user!=null){
				sql += "   AND A.MOVIE_USER='"+user+"'";
			}
			if(orderCol==1){
				sql += " ORDER BY A.MOVIE_PUBLISH_DATE DESC";
			}else if(orderCol==2){
			    sql += " ORDER BY NUM_OF_LIKES DESC";
			}else if(orderCol==3){
			    sql += " ORDER BY NUM_OF_HATES DESC";
			}
			
			xml = XSUUtils.getXMLSQL(sql,cn1,"Movies","Movie",null,null);
			logger.debug(XMLUtils.xmlToString(xml));
		}
		catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		}          
		finally {
			if (cn1 != null ) {
				cn1.close();
			}
		}//end of finally
		return (XMLNode)xml.getDocumentElement();
	}
	
	public XMLNode getResultLogged(String loggeduser) throws Exception {
		String sql = null;
		Connection cn1 = null;
		XMLDocument xml = null;
		
		try{
			cn1 = new CUSTConnection().GetNewConn();
			sql = 
			"SELECT A.MOVIE_ID,\n" +
			"       A.MOVIE_USER,\n" + 
			"       A.MOVIE_TITLE,\n" + 
			"       A.MOVIE_DESCRIPTION,\n" + 
			"       TO_CHAR(A.MOVIE_PUBLISH_DATE, 'DD/MM/YYYY HH24:MI:SS') AS MOVIE_PUBLISH_DATE,\n" + 
			"       (SELECT COUNT(*) FROM MOVIES_VOTES B WHERE B.MOVIE_ID=A.MOVIE_ID AND VOTE=1) AS NUM_OF_LIKES,\n" + 
			"       (SELECT COUNT(*) FROM MOVIES_VOTES B WHERE B.MOVIE_ID=A.MOVIE_ID AND VOTE=2) AS NUM_OF_HATES,\n" +
			"       TRUNC(SYSDATE)-TRUNC(A.MOVIE_PUBLISH_DATE) AS DATE_DIF,\n" +
			"		NVL(DECODE(A.MOVIE_USER, '"+loggeduser+"', 0, (SELECT B.VOTE FROM MOVIES_VOTES B WHERE B.MOVIE_ID=A.MOVIE_ID AND B.VOTE_USER='"+loggeduser+"')), 0) AS MYVOTE,\n" +
			"		'"+loggeduser+"' as LOGGED_USER\n" + 
			"  FROM MOVIES A" +
			" WHERE 1=1";
			if(!"".equals(user) && user!=null){
				sql += "   AND A.MOVIE_USER='"+user+"'";
			}
			if(orderCol==1){
				sql += " ORDER BY A.MOVIE_PUBLISH_DATE DESC";
			}else if(orderCol==2){
				sql += " ORDER BY NUM_OF_LIKES DESC, A.MOVIE_PUBLISH_DATE";
			}else if(orderCol==3){
				sql += " ORDER BY NUM_OF_HATES DESC, A.MOVIE_PUBLISH_DATE";
			}
			
			xml = XSUUtils.getXMLSQL(sql,cn1,"Movies","Movie",null,null);
			logger.debug(XMLUtils.xmlToString(xml));
		}
		catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		}          
		finally {
			if (cn1 != null ) {
				cn1.close();
			}
		}//end of finally
		return (XMLNode)xml.getDocumentElement();
	}
	
	public void insertMovie() throws Exception{
		String sql = null;
		Connection cn1 = null;
		Statement st = null;
	    ResultSet rs = null;
		PreparedStatement pst = null;
		String movieId = "";
		try {
			if(movieTitle==null || "".equals(movieTitle)){
				Exception e = new Exception("The title cannot ne empty!");
				throw e;
			}
			
			if(movieDescription==null || "".equals(movieDescription)){
				Exception e = new Exception("The description cannot ne empty!");
				throw e;
			}
			
		    if(movieUser==null || "".equals(movieUser)){
		        Exception e = new Exception("The user cannot ne empty!");
		        throw e;
		    }
			
			cn1 = new CUSTConnection().GetNewConn();
			st = cn1.createStatement();
			sql = "SELECT MOVIESEQ.NEXTVAL AS MOVIE_ID FROM DUAL";
			rs = st.executeQuery(sql);
			if(rs.next()){
			    movieId = rs.getString("MOVIE_ID");
			}
			
			sql = 
			"INSERT INTO MOVIES \n" + 
			"( \n" + 
			"MOVIE_ID, \n" + 
			"MOVIE_TITLE, \n" + 
			"MOVIE_DESCRIPTION, \n" + 
			"MOVIE_PUBLISH_DATE, \n" + 
			"MOVIE_USER \n" + 
			") \n" + 
			"VALUES \n" + 
			"( \n" + 
			"?, \n" + 
			"?, \n" + 
			"?, \n" + 
			"SYSDATE, \n" + 
			"? \n" + 
			")";
			
			pst = cn1.prepareStatement(sql);
		    pst.setString(1, movieId);
			pst.setString(2, movieTitle);
			pst.setString(3, movieDescription);
			pst.setString(4, movieUser);
			pst.executeUpdate();
			
			//st.execute(sql);
			
		} catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		} finally {
			if (cn1 != null ) {
				cn1.close();
			}
			
			if (st != null ) {
				st.close();
			}
			
		    if (pst != null ) {
		        pst.close();
		    }
			
		    if (rs != null ) {
		        rs.close();
		    }
		}
	}
	
	public int voteMovie(String movieId, String user, String vote) throws Exception{
		String sql = null;
		Connection cn1 = null;
		Statement st = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		int ret = 1;
		try {
			if(movieId==null || "".equals(movieId)){
				Exception e = new Exception("The movie id cannot ne empty!");
				throw e;
			}
			
			if(user==null || "".equals(user)){
				Exception e = new Exception("The user cannot ne empty!");
				throw e;
			}
			
		    if(vote==null || "".equals(vote)){
		        Exception e = new Exception("The vote cannot ne empty!");
		        throw e;
		    }
			
			cn1 = new CUSTConnection().GetNewConn();
			st = cn1.createStatement();
			
			boolean recexists = false;
		    sql = "SELECT 'X' FROM MOVIES_VOTES WHERE MOVIE_ID="+movieId+" AND VOTE_USER='"+user+"'";
			rs = st.executeQuery(sql);
			if(rs.next()){
			    recexists = true;
			}
			
			if("1".equals(vote) || "2".equals(vote)){
				if(!recexists){
					sql = 
					"INSERT INTO MOVIES_VOTES \n" + 
					"( \n" + 
					"MOVIE_ID, \n" + 
					"VOTE_USER, \n" + 
					"VOTE \n" + 
					") \n" + 
					"VALUES \n" + 
					"( \n" + 
					"?, \n" + 
					"?, \n" + 
					"? \n" + 
					")";
					pst = cn1.prepareStatement(sql);
					pst.setString(1, movieId);
					pst.setString(2, user);
					pst.setString(3, vote);
					pst.executeUpdate();
				}else{
					sql =
					"UPDATE MOVIES_VOTES SET VOTE=? WHERE MOVIE_ID=? AND VOTE_USER=?";
				    pst = cn1.prepareStatement(sql);
				    pst.setString(1, vote);
					pst.setString(2, movieId);
				    pst.setString(3, user);
				    pst.executeUpdate();
				}
			}else if("0".equals(vote)){
				sql = 
				"DELETE FROM MOVIES_VOTES WHERE MOVIE_ID=? AND VOTE_USER=?";
			    pst = cn1.prepareStatement(sql);
			    pst.setString(1, movieId);
			    pst.setString(2, user);
			    pst.executeUpdate();
			}
			//st.execute(sql);
			
		} catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		} finally {
			if (cn1 != null ) {
				cn1.close();
			}
			
			if (st != null ) {
				st.close();
			}
			
			if (pst != null ) {
				pst.close();
			}
			
		    if (rs != null ) {
		        rs.close();
		    }
		}
		return ret;
	}
	
	public static void main(String[] args) throws Exception{
//		Movies mv = new Movies();
//		mv.setOrderCol(1);
//		XMLDocument xml = mv.getResult().getDocument();
		
		String sql = 
			"SELECT MOVIE_ID,\n" +
			"       MOVIE_USER,\n" + 
			"       MOVIE_TITLE,\n" + 
			"       MOVIE_DESCRIPTION,\n" + 
			"       TO_CHAR(MOVIE_PUBLISH_DATE, 'DD/MM/YYYY HH24:MI:SS') AS MOVIE_PUBLISH_DATE,\n" + 
			"       NUM_OF_LIKES,\n" + 
			"       NUM_OF_HATES,\n" +
			"       TRUNC(SYSDATE)-TRUNC(MOVIE_PUBLISH_DATE) AS DATE_DIF\n" + 
			"  FROM MOVIES" +
			" WHERE 1=1" +
			"   AND MOVIE_USER='georgeh'";
		System.out.println(sql);
	}

	public void setHtml(String html) {
		this.html = html;
	}

	public String getHtml() throws Exception{
	    String xslname = "movies.xsl";
		try {
		    XMLDocument resultXML = new XMLDocument();
		    resultXML = getResult().getDocument();
		    html = XMLUtils.transformToString(resultXML, XMLUtils.parseResource("/xsl/"+xslname), null);
		} catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		}
		
		return html;
	}
	
	public String getHtmlLogged(String loggeduser) throws Exception{
		String xslname = "movieslogged.xsl";
		try {
			XMLDocument resultXML = new XMLDocument();
			resultXML = getResultLogged(loggeduser).getDocument();
			html = XMLUtils.transformToString(resultXML, XMLUtils.parseResource("/xsl/"+xslname), null);
		} catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		}
		
		return html;
	}

	public void setOrderCol(int orderCol) {
		this.orderCol = orderCol;
	}

	public int getOrderCol() {
		return orderCol;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getUser() {
		return user;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieDescription(String movieDescription) {
		this.movieDescription = movieDescription;
	}

	public String getMovieDescription() {
		return movieDescription;
	}

	public void setMovieUser(String movieUser) {
		this.movieUser = movieUser;
	}

	public String getMovieUser() {
		return movieUser;
	}
}
