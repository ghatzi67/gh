package com.workable.movie.app;

import java.io.IOException;

import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.log4j.Logger;


/**
 * Servlet Filter implementation class ReqFilterMobile
 */
public class ReqFilter implements Filter {
	private static Logger logger = Logger.getLogger(ReqFilter.class);

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	@SuppressWarnings("rawtypes")
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		//////////////FILTER CHARACTERS ///////////////
		Map<String, String[]> filteredParams = new TreeMap<String, String[]>();
		request.setCharacterEncoding("utf-8");
		String servletPath = ((HttpServletRequest) request).getServletPath();
		//String notlogged = request.getParameter("notlogged")!=null?request.getParameter("notlogged"):"";
		String userId = (String)((HttpServletRequest) request).getSession().getAttribute("userId")!=null?(String)((HttpServletRequest) request).getSession().getAttribute("userId"):"";
		
		if(!userId.equals("")){
			// check UUID
			if (!(servletPath.indexOf("/index.jsp") != -1) &&
				!(servletPath.indexOf("/index.html") != -1)
			) {
				if (!request.getParameterMap().isEmpty()) {
					String uuidFromCookie = null;
					String uuidFromRequest = request.getParameter("uuid");
			
					Cookie[] cookies = ((HttpServletRequest) request).getCookies();
	
					for (Cookie c: cookies) {
						if (c.getName().equals("UUID")) {
							uuidFromCookie = c.getValue();
						}
					}
					
					if (servletPath.indexOf("validateUser.jsp") == -1 && 
						servletPath.indexOf("errorPage.jsp") == -1 &&
						servletPath.indexOf("forgotMyPassword.jsp") == -1 &&
						servletPath.indexOf("userDetailsInsert.jsp") == -1 &&
						servletPath.indexOf("userDetailsInsert2.jsp") == -1 &&
						servletPath.indexOf("userDetailsInsert3.jsp") == -1 &&
						servletPath.indexOf("captcha") == -1)
					{
						if (uuidFromCookie == null || uuidFromRequest == null || !uuidFromCookie.equals(uuidFromRequest)) {
						    logger.debug("ReqFilter Error: Cookie Validation failed.");
						    logger.debug("UUID from Cookie: "+uuidFromCookie);
						    logger.debug("UUID from Request: "+uuidFromRequest);
							HttpServletResponse httpResp = (HttpServletResponse) response;
							httpResp.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
							return;
						}
						
						String requestSessionId = ((HttpServletRequest) request).getSession().getId();
						String loginSessionId = (String)((HttpServletRequest) request).getSession().getAttribute("sId");
						
						if (requestSessionId ==null || loginSessionId ==null || !requestSessionId.equalsIgnoreCase(loginSessionId)) {
						    logger.debug("ReqFilter Error: Session ID Validation failed.");
						    logger.debug("Session ID from Session: "+loginSessionId);
						    logger.debug("Session ID from Request: "+requestSessionId);
							HttpServletResponse httpResp = (HttpServletResponse) response;
							httpResp.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
							return;
						}
					}
				}
			}
		}

		Enumeration params = request.getParameterNames();

		while (params.hasMoreElements()) {
			String pName = (String) params.nextElement();
			//logger.debug("PARAMETER: " + pName);
			//logger.debug("VALUE: " + request.getParameter(pName));

			if (!pName.matches("(?s).*[-=\"()'<>{}\\[\\]\\\\#*;&%\\x00\\n\\r].*")) {
				//if ( !(servletPath.indexOf("/menu.jsp") != -1) && !(servletPath.indexOf("/trialCases.jsp") != -1) ) {
				if (!(servletPath.indexOf("/menu.jsp") != -1)) {
					Vector<String> values = new Vector<String>();
					for (String val: request.getParameterValues(pName)) {
						//if (val.matches("(?s).*[\"'<>{}\\[\\]\\\\#*;&%\\x00].*") || val.matches("(?is).*chr\\s*\\(\\s*\\d+\\s*\\).*")) {
						if (val.matches(".*[-=\"()'<>{}\\[\\]\\\\#*;&%\\x00].*")) {
							//if (!pName.equals("password")){
							logger.debug("ReqFilter Error: Invalid characters detected: " + pName + " = " + val +
										 " From: " + request.getRemoteHost() +
										 " URL: " + ((HttpServletRequest) request).getRequestURI());
//								val = val.replaceAll("(?s)[\"'<>{}\\[\\]\\\\#*;&%\\x00]", "");
//								val = val.replaceAll("(?is)chr\\s*\\(\\s*\\d+\\s*\\)", "");
							val = val.replaceAll("[-=\"()'<>{}\\[\\]\\\\#*;&%\\x00]", "");
							logger.debug("REPLACED: " + val);
							//}
						}

						values.add(val);
					}

					filteredParams.put(pName, values.toArray(new String[]{}));
				}
				else {
					filteredParams.put(pName, request.getParameterValues(pName));
				}
			}
		}

		String contentType = request.getContentType();
		if (contentType == null || !contentType.startsWith("multipart/form-data")){
			// pass the request along the filter chain
			chain.doFilter(new WrappedRequest((HttpServletRequest) request, filteredParams), response);
//		    chain.doFilter(new WrappedRequest((HttpServletRequest) request, filteredParams), new HttpServletResponseWrapper((HttpServletResponse) response) {
//				public void addHeader(String name, String value) {
//					if (!name.equalsIgnoreCase("X-ORACLE-DMS-ECID") && !name.equalsIgnoreCase("X-ORACLE-DMS-RID")) {
//						super.setHeader(name, value);
//					}
//				}
//			});
		}
		else {
			chain.doFilter(request, response);
//		    chain.doFilter(request, new HttpServletResponseWrapper((HttpServletResponse) response) {
//				public void addHeader(String name, String value) {
//					if (!name.equalsIgnoreCase("X-ORACLE-DMS-ECID") && !name.equalsIgnoreCase("X-ORACLE-DMS-RID")) {
//						super.setHeader(name, value);
//					}
//				}
//			});
		}

		HttpServletResponse httpResp = (HttpServletResponse)response;
		if (servletPath.indexOf("/images/") == -1 && servletPath.indexOf("/SpryAssets/") == -1 && servletPath.indexOf("/windowfiles/") == -1) {
			httpResp.setHeader("Pragma", "no-cache");
			httpResp.setHeader("Cache-Control", "no-cache");
			httpResp.addHeader("Cache-Control", "no-store");
//		    httpResp.setHeader("X-ORACLE-DMS-ECID", "");
//		    httpResp.setHeader("X-ORACLE-DMS-RID", "");
			httpResp.setDateHeader("Expires", 0);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		;
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		;
	}
}
