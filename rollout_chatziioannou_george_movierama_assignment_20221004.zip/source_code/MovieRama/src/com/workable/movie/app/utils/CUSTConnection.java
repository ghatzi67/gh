package com.workable.movie.app.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.HashMap;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

/**
 * Προσοχή ! Η κλαση είναι static. Μια αλλη αντιμετωπιση είναι μεσω application
 * variable στο JSP.
 * <pre>
 *  Example:
 *  <code>
 *  	PCSConnection PCSCon1 = new PCSConnection();
 *  	Connection cn1 = PCSCon1.GetNewConn();
 *  </code>
 * </pre>
 * The  max concurent connections is set to 100 through setMaxLimit property.
 * We <b>have</b> to check it. Tses 17.10.2000
 */
public class CUSTConnection {
    /** Εδώ κραταει τα Connections της getNewConn. */
	
    /** Εδώ κραταει τα Connections της getNewOracleConnection */
	private static HashMap<String, OracleDataSource> odsMap = new HashMap<String, OracleDataSource>();

    public Connection getNewOracleConnection(String id) throws Exception {
        return getNewOracleConnection(id, null);
    }

    /**
     * Γενικότερη μορφή των getNewConn & getNewConnL. Επιστρέφει ένα νέο
     * Connection για τη συγκεκριμένη σύνδεση.<br/>
     * <br/>
     * Η παράμετρος <code>id</code> καθορίζει τα ονόματα των παραμέτρων
     * από το PCSResource.properties:<br/>
     * <code>service<i>id</i></code>, <code>service<i>id</i>DS</code>, 
     * <code>useDataSource<i>id</i></code>, <code>user<i>id</i></code>,
     * <code>passwd<i>id</i></code> & <code>PoolMaxLimit<i>id</i></code>
     * π.χ. αν το id έχει τιμή "Test" οι αντίστοιχες παράμετροι είναι:</br>
     * <code>service<b>Test</b></code>, <code>service<b>Test</b>DS</code>,
     * <code>useDataSource<b>Test</b></code>, <code>user<b>Test</b></code>,
     * <code>passwd<b>Test</b></code> & <code>PoolMaxLimit<b>Test</b></code><br/>
     * <br/>
     * Η παράμετρος <code>useDataSource<i>id</i></code> καθορίζει αν για τη
     * συγκεκριμένη σύνδεση χρησιμοποιείται DataSource (τιμή: <code>1</code>)
     * ή όχι (τιμή: <code>0</code>).<br/>
     * Στην περίπτωση που χρησιμοιείται DataSource ή μόνη άλλη παράμετρος που πρέπει
     * να ορισθεί είναι η <code>service<b>Test</b>DS</code>. Αλλιώς πρέπει να ορισθούν
     * όλες οι υπόλοιπες παράμετροι (εκτός της <code>service<b>Test</b>DS</code>).
     *
     * @param id Το ενδεικτικό της σύνδεσης
     * @param clientInfo Πληροφορίες που θέλουμε να εισάγουμε στο πεδίο client_info του table v$session
     *
     * @return Το νέο Connection
     *
     * @throws SQLException
     */
	@SuppressWarnings("deprecation")
	public Connection getNewOracleConnection(String id, String clientInfo) throws Exception {
		if (com.workable.movie.app.utils.PropUtils.getResource("useDataSource" + id).equals("1")) {
			Connection cn = this.getNewDataSourceConnection(com.workable.movie.app.utils.PropUtils.getResource("service" + id + "DS"));
			CallableStatement cs = null;
			
			try {
				// set client_info
				if (clientInfo != null) {
					cs = cn.prepareCall("call dbms_application_info.set_client_info(?)");
					cs.setString(1, clientInfo);
					cs.execute();
				}
			} finally {
				if (cs != null) {
					cs.close();
				}
			}
			
			return cn;
		} else {
		    OracleDataSource ods = odsMap.get(id);
			
			if (ods == null) {
			    ods = new OracleDataSource();
			    ods.setConnectionCachingEnabled(true);
			    ods.setURL(com.workable.movie.app.utils.PropUtils.getResource("service" + id));
			    ods.setUser(com.workable.movie.app.utils.PropUtils.getResource("user" + id));
			    ods.setPassword(com.workable.movie.app.utils.PropUtils.getResource("passwd" + id));

			    Properties props = new Properties();
			    props.setProperty("MaxLimit", com.workable.movie.app.utils.PropUtils.getResource("PoolMaxLimit" + id));
			    props.setProperty("ValidateConnection", "true");

			    ods.setConnectionCacheProperties(props);

			    odsMap.put(id, ods);
			}
			
			Connection conn = null;
			Statement st = null;
			CallableStatement cs = null;
			ResultSet rs = null;
			
			try {
				conn = ods.getConnection();
				st = conn.createStatement();
				rs = st.executeQuery("select 'x' as x from dual");
				
				// set client_info
				if (clientInfo != null) {
					cs = conn.prepareCall("call dbms_application_info.set_client_info(?)");
					cs.setString(1, clientInfo);
					cs.execute();
				}
			} catch (SQLException ex) {
				System.err.print(ex.getMessage());
				
				// αν αποτύχει ο έλεγχος κλείνουμε τα πάντα και αφαιρούμε το συγκεκριμένο OracleConnectionCacheImpl από το HashMap
				if (conn != null) {
					if (rs != null) {
						rs.close();
						rs = null;
					}
					
					if (st != null) {
						st.close();
						st = null;
					}
					
					if (cs != null) {
						cs.close();
						cs = null;
					}
					
					conn.close();
				}
				
				conn = null;
				
				ods.close();
				ods = null;
				odsMap.remove(id);
				
				throw ex;
			} finally {
				// σε περίπτωση που περάσει ο έλεγχος κλείνουμε το ResultSet και το Statement
				if (rs != null) {
					rs.close();
					rs = null;
				}
				
				if (st != null) {
					st.close();
					st = null;
				}
				
				if (cs != null) {
					cs.close();
					cs = null;
				}
			}
			
			return conn;
		}
	}

    /**
     * Επιστρέφει ένα νέο Connection για το συγκεκριμένο DataSource.
     *
     * @param jndiLocation Το ενδεικτικό του DataSource
     *
     * @return Το νέο Connection
     *
     * @throws SQLException
     */
    private Connection getNewDataSourceConnection(String jndiLocation) throws SQLException {
        Connection conn = null;

        try {
            Context ic = new InitialContext();
            DataSource ds = (DataSource)ic.lookup(jndiLocation);
            conn = ds.getConnection();
        } catch (NamingException ex) {
            System.err.print(ex.getMessage());
            throw new SQLException("Unable to Connect to DataSource \"" + jndiLocation + "\" (PCS) \n" + ex.getMessage());
        }

        return conn;
    }

    /**
	 * Επιστρέφει ένα νέο Connection για τη συγκεκριμένη JDBC σύνδεση.
	 * Η παράμετρος <code>id</code> καθορίζει τα ονόματα των παραμέτρων
	 * από το PCSResource.properties:<br/>
	 * <br/>
	 * Η παράμετρος <code>id</code> καθορίζει τα ονόματα των παραμέτρων
	 * από το PCSResource.properties:<br/>
	 * <code>service<i>id</i></code>, <code>service<i>id</i>DS</code>,
	 * <code>useDataSource<i>id</i></code>, <code>user<i>id</i></code>,
	 * <code>passwd<i>id</i></code> & <code>PoolMaxLimit<i>id</i></code>
	 * π.χ. αν το id έχει τιμή "Test" οι αντίστοιχες παράμετροι είναι:</br>
	 * <code>service<b>Test</b></code>, <code>service<b>Test</b>DS</code>,
	 * <code>useDataSource<b>Test</b></code>, <code>user<b>Test</b></code>,
	 * <code>passwd<b>Test</b></code> & <code>PoolMaxLimit<b>Test</b></code><br/>
	 * <br/>
	 * Η παράμετρος <code>useDataSource<i>id</i></code> καθορίζει αν για τη
	 * συγκεκριμένη σύνδεση χρησιμοποιείται DataSource (τιμή: <code>1</code>)
	 * ή όχι (τιμή: <code>0</code>).<br/>
	 * Στην περίπτωση που χρησιμοιείται DataSource ή μόνη άλλη παράμετρος που πρέπει
	 * να ορισθεί είναι η <code>service<b>Test</b>DS</code>. Αλλιώς πρέπει να ορισθούν
	 * όλες οι υπόλοιπες παράμετροι (εκτός της <code>service<b>Test</b>DS</code>).
	 *
	 * @param id Το ενδεικτικό της σύνδεσης
	 *
	 * @return Το νέο Connection
	 *
	 * @throws SQLException
	 * @throws CUSTException
	 */
    public Connection getNewJdbcConnection(String id) throws SQLException, CUSTException {
        return getNewJdbcConnection(id, null);
    }

     /**
	 * Επιστρέφει ένα νέο Connection για τη συγκεκριμένη JDBC σύνδεση.<br/>
	 * Λειτουργέι όπως και η getNewJdbcConnection με την δυνατότητα της χρήσης περισσότερων παραμέτρων
	 * (π.χ. CHARSET) μέσω του ορίσματος <code>props</code>.<br/>
	 * <br/>
	 * <b>ΣΗΜΕΙΩΣΗ:</b><br/>
	 * Σε περίπτωση που χρησιμοποιείται DataSource, το όρισμα <code>props</code> αγνοείται.
	 *
	 * @param id Το ενδεικτικό της σύνδεσης
	 * @param props Άλλες παράμετροι
	 *
	 * @return Το νέο Connection
	 *
	 * @throws SQLException
	 * @throws CUSTException
	 */
    public Connection getNewJdbcConnection(String id, Properties props) throws SQLException, CUSTException {
        if (com.workable.movie.app.utils.PropUtils.getResource("useDataSource" + id).equals("1")) {
            return this.getNewDataSourceConnection(com.workable.movie.app.utils.PropUtils.getResource("service" + id + "DS"));
        } else {
            if (props == null) {
                props = new Properties();
            }

            try {
                DriverManager.registerDriver((Driver)Class.forName(com.workable.movie.app.utils.PropUtils.getResource("jdbcClass" + id)).newInstance());
            } catch (Exception ex) {
                System.err.println(ex.getMessage());
                throw new CUSTException(ex.getMessage());
            }

            String url = com.workable.movie.app.utils.PropUtils.getResource("service" + id);
            String userid = com.workable.movie.app.utils.PropUtils.getResource("user" + id);
            String pwd = com.workable.movie.app.utils.PropUtils.getResource("passwd" + id);
            props.put("user", userid);
            props.put("password", pwd);

            Connection conn = DriverManager.getConnection(url, props);

            return conn;
        }
    }

    /**
     * To user name και password είναι <b>εδω</b>. Θα πρέπει να αλλάζει ανάλογα
     * με τον Πελάτη ή να προστεθεί property file
     *
     * @return Connection η νέα σύνδεση
     *
     * @throws SQLException
     */
	@SuppressWarnings("deprecation")
    public Connection GetNewConn() throws SQLException {
        if (!com.workable.movie.app.utils.PropUtils.getResource("USEDATASOURCE").equals("1")) {
			OracleDataSource ods = odsMap.get("");
//			if (ods == null) {
                ods = new OracleDataSource();
                ods.setURL(com.workable.movie.app.utils.PropUtils.getResource("service"));
                ods.setUser(com.workable.movie.app.utils.PropUtils.getResource("user"));
                ods.setPassword(com.workable.movie.app.utils.PropUtils.getResource("passwd"));
				Properties props = new Properties();
				props.setProperty("MaxLimit", com.workable.movie.app.utils.PropUtils.getResource("PoolMaxLimit"));
				props.setProperty("ValidateConnection", "true");

				ods.setConnectionCacheProperties(props);

				odsMap.put("", ods);
//            }

            Connection conn = null;
            conn = ods.getConnection();

            String SQLString = " select 'x' as x from dual ";
            Statement st = null;
            ResultSet rset = null;
            st = conn.createStatement();

            try {
                rset = st.executeQuery(SQLString);
            } catch (SQLException e) {
                System.err.print(e.getMessage());
                conn = null;
                ods.close();
                ods = null;
                throw e;
            }

            st.close();
            rset.close();

            return conn;
        } else {
            String jndiLocation = "jdbc/PCSRemoteDS";
            try {
                jndiLocation = com.workable.movie.app.utils.PropUtils.getResource("serviceRDS");
            } catch (Exception ex) {
                System.err.println("Property \"serviceRDS\" not found!");
            }

            try {
                Context ic = new InitialContext();
                DataSource ds = (DataSource)ic.lookup(jndiLocation);
                Connection conn = ds.getConnection();

                return conn;
            } catch (NamingException n) {
                System.err.println(n.getMessage());
                throw new SQLException("Unable to Connect to Datasource Remote (PCS)");
            }
        }
    }

}
