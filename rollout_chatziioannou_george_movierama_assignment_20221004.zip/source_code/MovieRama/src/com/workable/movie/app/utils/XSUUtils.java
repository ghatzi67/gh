package com.workable.movie.app.utils;

import java.sql.Connection;

import java.sql.ResultSet;

import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.sql.query.OracleXMLQuery;

import org.w3c.dom.Document;

/**
 * <p>Includes utilities for fetching XML data from a database connection using Oracle's XSU API.</p>
 * 
 * <p>The default encoding for the resulting XML documents is UTF-8.<br>
 * The default date format is set according to {@link PropUtils#getDefaultDateFormat}.<br>
 * The default name for the rowset tag (root tag) of the resulting XML is "R"<br>
 * and the default name for the row tags (data tags) is "D".</p>
 * 
 * @see oracle.xml.sql.query.OracleXMLQuery
 */
public class XSUUtils {
	private static final String DEFAULT_FORMAT = PropUtils.getDefaultDateFormat();
	private static final String DEFAULT_ENCODING = "UTF-8";
	private static final String DEFAULT_ROWSET_TAG = "R";
	private static final String DEFAULT_ROW_TAG = "D";

	/**
	 * Executes a SQL query against the provided database connection
	 * and returns the results as a {@code XMLDocument} object using the default parameters.
	 *
	 * @param sql A SQL query.
	 * @param cn  A {@code Connection} to a database.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(String sql, Connection cn) {
		return getXMLSQL(sql, cn, DEFAULT_ROWSET_TAG, DEFAULT_ROW_TAG, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}
	
	/**
	 * Executes a SQL query against the provided database connection and returns the results
	 * as a {@code XMLDocument} object using the provided rowset and row tag names and default date format and encoding.
	 *
	 * @param sql       A SQL query.
	 * @param cn        A {@code Connection} to a database.
	 * @param rowsetTag The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag    The name for the row tags to use. If {@code null} the default row tag name is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(String sql, Connection cn, String rowsetTag, String rowTag) {
		return getXMLSQL(sql, cn, rowsetTag, rowTag, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}
	
	/**
	 * Executes a SQL query against the provided database connection and returns the results
	 * as a {@code XMLDocument} object using the provided parameters.
	 *
	 * @param sql        A SQL query.
	 * @param cn         A {@code Connection} to a database.
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * @param dateFormat The date format pattern to use. If {@code null} the default date format pattern is used.
	 * @param encoding   The encoding for the resulting XML. If {@code null} the default encoding is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(String sql, Connection cn, String rowsetTag, String rowTag, String dateFormat, String encoding) {
		if ((encoding == null) || encoding.equals("")) {
			encoding = DEFAULT_ENCODING;
		}

		if ((dateFormat == null) || dateFormat.equals("")) {
			dateFormat = DEFAULT_FORMAT;
		}

		if ((rowsetTag == null) || rowsetTag.equals("")) {
			rowsetTag = DEFAULT_ROWSET_TAG;
		}

		if ((rowTag == null) || rowTag.equals("")) {
			rowTag = DEFAULT_ROW_TAG;
		}

		OracleXMLQuery xmlSql = new OracleXMLQuery(cn, sql);
		xmlSql.setEncoding(encoding);
		xmlSql.setDateFormat(dateFormat);
		xmlSql.setRowsetTag(rowsetTag);
		xmlSql.setRowTag(rowTag);
		xmlSql.setRaiseException(true);

		return (XMLDocument) xmlSql.getXMLDOM();
	}


	/**
	 * Executes a SQL query against the provided database connection using the provided parameters
	 * and returns the underlying schema(s) as a {@code org.w3c.dom.Document} array.
	 *
	 * @param sql        		A SQL query.
	 * @param cn         		A {@code Connection} to a database.
	 * @param rowsetTag  		The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     		The name for the row tags to use. If {@code null} the default row tag name is used.
	 * @param dateFormat 		The date format pattern to use. If {@code null} the default date format pattern is used.
	 * @param encoding   		The encoding for the resulting XML. If {@code null} the default encoding is used.
	 * @param rowIdAttrName		The name of the id attribute of the row enclosing tag.
	 * 							If {@code null} or an empty string the row id attribute is omitted.
	 * @param rowIdAttrValue	The scalar column whose value is to be assigned to the id attribute of the row enclosing tag.
	 * 							If {@code null} or an empty string the row id attribute is assigned the row count value (i.e. 0, 1, 2 and so on).
	 * 
	 * @return The underlying schema(s) of the SQL query as a {@code org.w3c.dom.Document} array.
	 */
	public static Document[] getXSDSQL(String sql, Connection cn, String rowsetTag, String rowTag, String dateFormat, String encoding, String rowIdAttrName, String rowIdAttrValue) {
		if ((encoding == null) || encoding.equals("")) {
			encoding = DEFAULT_ENCODING;
		}

		if ((dateFormat == null) || dateFormat.equals("")) {
			dateFormat = DEFAULT_FORMAT;
		}

		if ((rowsetTag == null) || rowsetTag.equals("")) {
			rowsetTag = DEFAULT_ROWSET_TAG;
		}

		if ((rowTag == null) || rowTag.equals("")) {
			rowTag = DEFAULT_ROW_TAG;
		}
		
		OracleXMLQuery xmlSql = new OracleXMLQuery(cn, sql);
		xmlSql.setEncoding(encoding);
		xmlSql.setDateFormat(dateFormat);
		
		if ((rowIdAttrName != null) ) {
			xmlSql.setRowIdAttrName(rowIdAttrName);
		}
		
		if ((rowIdAttrValue != null) ) {
			xmlSql.setRowIdAttrValue(rowIdAttrValue);    
		}

		xmlSql.setRowsetTag(rowsetTag);
		xmlSql.setRowTag(rowTag);
		xmlSql.setRaiseException(true);

		return xmlSql.getXMLSchema();
	}

	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the default parameters.</p>
	 * 
	 * <p>A "page" is a subset of the records returned by the query and is defined by a page index and length.<br>
	 * The page length, defined by {@code maxRows}, is the maximum number of records to include in the resulting XML,
	 * while its index defines the number of records to skip from the start of the corresponding resultset.<br>
	 * This number of records to skip is calculated according to the formula {@code maxRows} * {@code pageNo}, thus the first record in the
	 * resulting XML should be the ({@code maxRows} * {@code pageNo} + 1)th record of the corresponding resultset.</p>
	 * 
	 * <p>The attribute {@code hasMorePages} of the resulting XML's root element indicates whether there exist ({@code true})
	 * more following records in the underlying resultset or not ({@code false}).</p>
	 *
	 * @param sql        A SQL query.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(String sql, Connection cn, int maxRows, int pageNo) {
		return getPagedXMLSQL(sql, cn, maxRows, pageNo, DEFAULT_ROWSET_TAG, DEFAULT_ROW_TAG, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}

	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the provided rowset and row tag names and default date format and encoding.</p>
	 * 
	 * <p>For more information see {@link #getPagedXMLSQL(String, Connection, int, int)}.</p>
	 *
	 * @param sql        A SQL query.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(String sql, Connection cn, int maxRows, int pageNo, String rowsetTag, String rowTag) {
		return getPagedXMLSQL(sql, cn, maxRows, pageNo, rowsetTag, rowTag, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}

	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the provided parameters.</p>
	 * 
	 * <p>For more information see {@link #getPagedXMLSQL(String, Connection, int, int)}.</p>
	 *
	 * @param sql        A SQL query.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * @param dateFormat The date format pattern to use. If {@code null} the default date format pattern is used.
	 * @param encoding   The encoding for the resulting XML. If {@code null} the default encoding is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(String sql, Connection cn, int maxRows, int pageNo, String rowsetTag, String rowTag, String dateFormat, String encoding) {
		if ((encoding == null) || encoding.equals("")) {
			encoding = DEFAULT_ENCODING;
		}

		if ((dateFormat == null) || dateFormat.equals("")) {
			dateFormat = DEFAULT_FORMAT;
		}

		if ((rowsetTag == null) || rowsetTag.equals("")) {
			rowsetTag = DEFAULT_ROWSET_TAG;
		}

		if ((rowTag == null) || rowTag.equals("")) {
			rowTag = DEFAULT_ROW_TAG;
		}

		OracleXMLQuery xmlSql = new OracleXMLQuery(cn, sql);
		xmlSql.setEncoding(encoding);
		xmlSql.setDateFormat(dateFormat);
		xmlSql.setRowsetTag(rowsetTag);
		xmlSql.setRowTag(rowTag);
		xmlSql.setRaiseException(true);

		if (maxRows > 0) {
			xmlSql.setMaxRows(maxRows + 1);

		    if (pageNo >= 0) {
		        xmlSql.setSkipRows(maxRows * pageNo);
		    }
		}
		else {
			pageNo = 0;
		}

		XMLDocument tempXML = (XMLDocument) xmlSql.getXMLDOM();
		tempXML.getDocumentElement().setAttribute("pageNo", "" + pageNo);

		long rows = xmlSql.getNumRowsProcessed();

		if (maxRows > 0 && rows > maxRows) {
			tempXML.getDocumentElement().setAttribute("hasMorePages", "true");
			tempXML.getDocumentElement().removeChild(tempXML.getDocumentElement().getLastChild());
		} else {
			tempXML.getDocumentElement().setAttribute("hasMorePages", "false");
		}

		return tempXML;
	}
	
	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the provided parameters.</p>
	 * 
	 * <p>For more information see {@link #getPagedXMLSQL(String, Connection, int, int)}.</p>
	 *
	 * @param rs         A result set.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * @param dateFormat The date format pattern to use. If {@code null} the default date format pattern is used.
	 * @param encoding   The encoding for the resulting XML. If {@code null} the default encoding is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(ResultSet rs, Connection cn, int maxRows, int pageNo, String rowsetTag, String rowTag, String dateFormat, String encoding) {
		if ((encoding == null) || encoding.equals("")) {
			encoding = DEFAULT_ENCODING;
		}

		if ((dateFormat == null) || dateFormat.equals("")) {
			dateFormat = DEFAULT_FORMAT;
		}

		if ((rowsetTag == null) || rowsetTag.equals("")) {
			rowsetTag = DEFAULT_ROWSET_TAG;
		}

		if ((rowTag == null) || rowTag.equals("")) {
			rowTag = DEFAULT_ROW_TAG;
		}

		OracleXMLQuery xmlSql = new OracleXMLQuery(cn, rs);
		xmlSql.setEncoding(encoding);
		xmlSql.setDateFormat(dateFormat);
		xmlSql.setRowsetTag(rowsetTag);
		xmlSql.setRowTag(rowTag);
		xmlSql.setRaiseException(true);

		if (maxRows > 0) {
			xmlSql.setMaxRows(maxRows + 1);

			if (pageNo >= 0) {
				xmlSql.setSkipRows(maxRows * pageNo);
			}
		}
		else {
			pageNo = 0;
		}

		XMLDocument tempXML = (XMLDocument) xmlSql.getXMLDOM();
		tempXML.getDocumentElement().setAttribute("pageNo", "" + pageNo);

		long rows = xmlSql.getNumRowsProcessed();

		if (maxRows > 0 && rows > maxRows) {
			tempXML.getDocumentElement().setAttribute("hasMorePages", "true");
			tempXML.getDocumentElement().removeChild(tempXML.getDocumentElement().getLastChild());
		} else {
			tempXML.getDocumentElement().setAttribute("hasMorePages", "false");
		}

		return tempXML;
	}
	
	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the default parameters.</p>
	 * 
	 * <p>A "page" is a subset of the records returned by the query and is defined by a page index and length.<br>
	 * The page length, defined by {@code maxRows}, is the maximum number of records to include in the resulting XML,
	 * while its index defines the number of records to skip from the start of the corresponding resultset.<br>
	 * This number of records to skip is calculated according to the formula {@code maxRows} * {@code pageNo}, thus the first record in the
	 * resulting XML should be the ({@code maxRows} * {@code pageNo} + 1)th record of the corresponding resultset.</p>
	 * 
	 * <p>The attribute {@code hasMorePages} of the resulting XML's root element indicates whether there exist ({@code true})
	 * more following records in the underlying resultset or not ({@code false}).</p>
	 *
	 * @param rs         A result set.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(ResultSet rs, Connection cn, int maxRows, int pageNo) {
		return getPagedXMLSQL(rs, cn, maxRows, pageNo, DEFAULT_ROWSET_TAG, DEFAULT_ROW_TAG, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}
	
	/**
	 * <p>Executes a SQL query against the provided database connection and returns a "page" of the results
	 * as a {@code XMLDocument} object using the provided rowset and row tag names and default date format and encoding.</p>
	 * 
	 * <p>For more information see {@link #getPagedXMLSQL(String, Connection, int, int)}.</p>
	 *
	 * @param rs         A result set.
	 * @param cn         A {@code Connection} to a database.
	 * @param maxRows    The page length (maximum number of rows to fetch). 0 = all (disable paging)
	 * @param pageNo     The page's index (zero based).
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getPagedXMLSQL(ResultSet rs, Connection cn, int maxRows, int pageNo, String rowsetTag, String rowTag) {
		return getPagedXMLSQL(rs, cn, maxRows, pageNo, rowsetTag, rowTag, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}

	/**
	 * Executes a SQL query against the provided database connection
	 * and returns the results as a {@code XMLDocument} object using the default parameters.
	 *
	 * @param rs  A result set.
	 * @param cn  A {@code Connection} to a database.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(ResultSet rs, Connection cn) {
		return getXMLSQL(rs, cn, DEFAULT_ROWSET_TAG, DEFAULT_ROW_TAG, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}
	
	/**
	 * Executes a SQL query against the provided database connection and returns the results
	 * as a {@code XMLDocument} object using the provided rowset and row tag names and default date format and encoding.
	 *
	 * @param rs        A result set.
	 * @param cn        A {@code Connection} to a database.
	 * @param rowsetTag The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag    The name for the row tags to use. If {@code null} the default row tag name is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(ResultSet rs, Connection cn, String rowsetTag, String rowTag) {
		return getXMLSQL(rs, cn, rowsetTag, rowTag, DEFAULT_FORMAT, DEFAULT_ENCODING);
	}
	
	/**
	 * Executes a SQL query against the provided database connection and returns the results
	 * as a {@code XMLDocument} object using the provided parameters.
	 *
	 * @param rs         A result set.
	 * @param cn         A {@code Connection} to a database.
	 * @param rowsetTag  The name for the rowset tag to use. If {@code null} the default rowset tag name is used.
	 * @param rowTag     The name for the row tags to use. If {@code null} the default row tag name is used.
	 * @param dateFormat The date format pattern to use. If {@code null} the default date format pattern is used.
	 * @param encoding   The encoding for the resulting XML. If {@code null} the default encoding is used.
	 * 
	 * @return The results of the SQL query as a {@code XMLDocument} object.
	 */
	public static XMLDocument getXMLSQL(ResultSet rs, Connection cn, String rowsetTag, String rowTag, String dateFormat, String encoding) {
		if ((encoding == null) || encoding.equals("")) {
			encoding = DEFAULT_ENCODING;
		}

		if ((dateFormat == null) || dateFormat.equals("")) {
			dateFormat = DEFAULT_FORMAT;
		}

		if ((rowsetTag == null) || rowsetTag.equals("")) {
			rowsetTag = DEFAULT_ROWSET_TAG;
		}

		if ((rowTag == null) || rowTag.equals("")) {
			rowTag = DEFAULT_ROW_TAG;
		}

		OracleXMLQuery xmlSql = new OracleXMLQuery(cn, rs);
		xmlSql.setEncoding(encoding);
		xmlSql.setDateFormat(dateFormat);
		xmlSql.setRowsetTag(rowsetTag);
		xmlSql.setRowTag(rowTag);
		xmlSql.setRaiseException(true);

		return (XMLDocument) xmlSql.getXMLDOM();
	}
}
