package com.workable.movie.app.utils;

public class ClassUtils {

	/**
	 * Gets the location from which the class is loaded
	 *
	 * @param cls	The class
	 * @return The classpath or null
	 */
	public static String getClassLocation(Class cls) {
		String path = null;

		try {
			path = cls.getProtectionDomain().getCodeSource().getLocation().getPath();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return path;
	}
}
