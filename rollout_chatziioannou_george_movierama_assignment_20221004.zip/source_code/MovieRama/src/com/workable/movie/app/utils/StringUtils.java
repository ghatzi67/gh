package com.workable.movie.app.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.ArrayList;

/**
 * Includes utilities for manipulating strings.
 */
public class StringUtils {
	/**
	 * Checks if a string is either null or contains nothing but spaces.
	 *
	 * @param str A string to check.
	 *
	 * @return false - If the string contains at least one non space character.
	 */
	public static boolean isBlank(String str) {
		if (str == null) {
			return true;
		}

		return (str.trim().length() == 0);
	}

	/**
	 * <p>Correctly capitalizes a greek string.</p>
	 *
	 * <p>In greek uppercase strings should not contain accented characters.<br>
	 * This function replaces the accented characters in the string returned by {@code str.toUpperCase()}
	 * with their non-accented equivalents.</p>
	 *
	 * @param str A string.
	 *
	 * @return The capitalized string.
	 */
	public static String toUpperGR(String str) {
		if (str != null) {
			str = str.toUpperCase();

			char[] from = { 'Ά', 'Έ', 'Ή', 'Ί', 'Ό', 'Ύ', 'Ώ', 'ΐ', 'ΰ' };
			char[] to = { 'Α', 'Ε', 'Η', 'Ι', 'Ο', 'Υ', 'Ω', 'Ϊ', 'Ϋ' };

			for (int i = 0; i < from.length; i++) {
				str = str.replace(from[i], to[i]);
			}
		}

		return str;
	}

	/**
	 * Appends spaces at the end of the string until its length matches the provided {@code size} argument.<br>
	 * If the string's length is equal or greater than {@code size}, the original string is returned.
	 *
	 * @param str  A string.
	 * @param size An integer specifying the minimum length of the returned string.
	 *
	 * @return A right padded string (or the original).
	 */
	public static String rPad(String str, int size) {
		String format = "%1$-" + size + "s";
		return String.format(format, new Object[] {str});
	}

	/**
	 * Prepends the specified character at the start of the string until its length matches the provided {@code size} argument.<br>
	 * If the string's length is equal or greater than {@code size}, the original string is returned.
	 *
	 * @param str  A string.
	 * @param size An integer specifying the minimum length of the returned string.
	 * @param ch   A char.
	 *
	 * @return A left padded string (or the original).
	 */
	public static String lPad(String str, int size, char ch) {
		while (str.length() < size) {
			str = ch + str;
		}

		return str;
	}

	/**
	 * Appends the specified character at the end of the string until its length matches the provided {@code size} argument.<br>
	 * If the string's length is equal or greater than {@code size}, the original string is returned.
	 *
	 * @param str  A string.
	 * @param size An integer specifying the minimum length of the returned string.
	 * @param ch   A char.
	 *
	 * @return A right padded string (or the original).
	 */
	public static String rPad(String str, int size, char ch) {
		while (str.length() < size) {
			str += ch;
		}

		return str;
	}

	/**
	 * Prepends spaces at the start of the string until its length matches the provided {@code size} argument.<br>
	 * If the string's length is equal or greater than {@code size}, the original string is returned.
	 *
	 * @param str  A string.
	 * @param size An integer specifying the minimum length of the returned string.
	 *
	 * @return A left padded string (or the original).
	 */
	public static String lPad(String str, int size) {
		String format = "%1$" + size + "s";
		return String.format(format, new Object[] {str});
	}

	/**
	 * Truncates a string to {@code length} characters.<br>
	 * If the string's length is equal or less than {@code length}, the original string is returned.
	 *
	 * @param str    A string.
	 * @param length The maximum length of the returned string.
	 *
	 * @return The truncated string (or the original).
	 */
	public static String truncate(String str, int length) {
		if (str.length() > length) {
			str = str.substring(0, length);
		}

		return str;
	}

	/**
	 * Removes all spaces from a string.
	 *
	 * @param str A string.
	 *
	 * @return A string with no spaces.
	 */
	public static String stripSpace(String str) {
		if (str == null) {
			return null;
		}

		/*
			while (str.indexOf(" ") != -1) {
				str = str.substring(0, str.indexOf(" ")) +	str.substring(str.indexOf(" ") + 1);
			}

			return str;
		*/
		return str.replaceAll(" ", "");
	}

	/**
	 * Removes all occurences of the specified character from a string.
	 *
	 * @param str A string.
	 * @param c   The character to remove.
	 *
	 * @return A string with no {@code c} characters.
	 */
	public static String stripChar(String str, char c) {
		while (str.indexOf(c) != -1) {
			str = str.substring(0, str.indexOf(c)) + str.substring(str.indexOf(c) + 1);
		}

		return str;
	}

	/**
	 * Replaces all occurences of a specified substring with a new substring in a string.
	 *
	 * @param str    A string.
	 * @param oldStr The substring to be replaced.
	 * @param newStr The replacement substring.
	 *
	 * @return A string where all occurences of {@code oldStr} have been replaced with {@code newStr}.
	 */
	public static String replaceAll(String str, String oldStr, String newStr) {
		String result = str;
		int pos = 0;
		int start = 0;
		String beg;
		String end;

		while ((pos = result.indexOf(oldStr, start)) != -1) {
			if (pos > 0) {
				beg = result.substring(0, pos);
			} else {
				beg = "";
			}

			end = result.substring(pos + oldStr.length(), result.length());
			start = pos + newStr.length();
			result = beg + newStr + end;
		}

		return result;
	}

	/**
	 * Parses a comma delimited string to an array of strings.
	 *
	 * @deprecated Use {@code String[] s = str.split("\\s*,\\s*")} instead.
	 *
	 * @param str A comma delimited string to parse.
	 *
	 * @return An array of strings.
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Deprecated
	public static String[] parseCommaDelimited(String str) {
		ArrayList arraylist = new ArrayList();
		int startstring = 0;
		int endstring = str.indexOf(',');
		int counter = 1;

		while (endstring != -1) {
			counter++;
			arraylist.add(str.substring(startstring, endstring).trim());
			startstring = endstring + 1;
			endstring = str.indexOf(',', endstring + 1);
		}

		arraylist.add(str.substring(startstring, str.length()).trim());

		String[] ss = new String[counter];

		for (int i = 0; i < counter; i++) {
			ss[i] = (String) arraylist.get(i);
		}

		return ss;
	}

	/**
	 * Hashes the provided string using the MD5 algorithm.
	 *
	 * @param str A string.
	 *
	 * @return The hashed string (max 32 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @deprecated Produces wrong hex strings. Use {@link HashUtils} instead.
	 */
	@Deprecated
	public static String md5(String str) throws NoSuchAlgorithmException {
		return hash(str, "md5");
	}

	/**
	 * Hashes the provided string using the SHA-1 algorithm.
	 *
	 * @param str A string.
	 *
	 * @return The hashed string (max 40 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @deprecated Produces wrong hex strings. Use {@link HashUtils} instead.
	 */
	@Deprecated
	public static String sha1(String str) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("sha-1");
		byte[] b = md.digest(str.getBytes());
		String s = "";
		for (int i=0; i < b.length; i ++) {
			s += Integer.toHexString(b[i] + 128);
		}
		return s;
	}

	/**
	 * Hashes the provided string using the SHA-1 algorithm.
	 *
	 * @param str A string.
	 *
	 * @return The hashed string (max 40 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @deprecated Produces wrong hex strings. Use {@link HashUtils} instead.
	 */
	@Deprecated
	public static String sha(String str) throws NoSuchAlgorithmException {
		return sha(str, 128);
	}

	/**
	 * Hashes the provided string using the equivalent SHA algorithm for the specified {@code bitStrength}
	 *
	 * @param str         A string.
	 * @param bitStrength The required strength for the SHA algorithm in bits.<br>
	 *                    Supported values are: 128, 256, 384 and 512.<br>
	 *                    If an unsupported value is specified the default value of 128 is used instead.
	 *
	 * @return The hashed string (max 40 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @deprecated Produces wrong hex strings. Use {@link HashUtils} instead.
	 */
	@Deprecated
	public static String sha(String str, int bitStrength) throws NoSuchAlgorithmException {
		String algorithm = "SHA-1";

		switch (bitStrength) {
			case 256:
				algorithm = "SHA-256";
			break;

			case 384:
				algorithm = "SHA-384";
			break;

			case 512:
				algorithm = "SHA-512";
			break;

			default:
				algorithm = "SHA-1";
		}

		return hash(str, algorithm);
	}

	/**
	 * Hashes the provided string using the specified algorithm.
	 *
	 * @param str A string.
	 * @param algorithm The standard name of the digest algorithm.
	 *
	 * @return The hashed string.
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @deprecated Produces wrong hex strings. Use {@link HashUtils} instead.
	 *
	 * @see java.security.MessageDigest
	 */
	@Deprecated
	public static String hash(String str, String algorithm) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance(algorithm);
		byte[] b = md.digest(str.getBytes());
		String s = "";
		for (int i=0; i < b.length; i ++) {
			String highByte = Integer.toHexString(b[i] >>> 4 & 0xF);
			String lowByte = Integer.toHexString(b[i] & 0xF);
			s += highByte + lowByte;
		}
		return s;
	}
}
