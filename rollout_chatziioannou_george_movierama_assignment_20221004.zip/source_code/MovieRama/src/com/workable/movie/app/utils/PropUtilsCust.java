package com.workable.movie.app.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.io.InputStream;

import java.net.URI;
import java.net.URISyntaxException;

import java.net.URL;

import java.text.MessageFormat;

import java.util.HashMap;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

/**
 * <p>Includes utilities for retrieving properties/messages from resource bundles.</p>
 * <p>The default bundle for simple properties is "{@code PCSResource.properties}" (resource bundle)<br>
 * and for localized (i18n) messages is "{@code PCSMessages.properties}" (messages bundle).</p>
 *
 * <p>For information about the default application locale see {@link #getDefaultLocale}.</p>
 *
 * @see java.util.ResourceBundle
 * @see java.util.Properties
 * @see java.text.MessageFormat
 */
public class PropUtilsCust {
	private static final String DEFAULT_BUNDLE = "PCSResource";
	private static final String DEFAULT_MESSAGE_BUNDLE = getDefaultMsgBundle();
	private static HashMap<String, TimedProperty> bundles = new HashMap<String, TimedProperty>();

	/* This is a simple class that keeps the last modification date for a Properties object.
	 * It is used by some of the class's methods to determine whether a properties file needs to be reloaded. */
	private static class TimedProperty {
		Properties bundle;
		long lastModified;

		public TimedProperty(Properties bundle, long lastModified) {
			this.bundle = bundle;
			this.lastModified = lastModified;
		}
	}

	/* Fetches the default message bundle from the default resource bundle */
	private static String getDefaultMsgBundle() {
		String msgBundle = "PCSMessages";
		
		try {
		    msgBundle = com.workable.movie.app.utils.PropUtils.getResource("defaultMessageBundle");
		}
		catch (Exception ex) {
			;
		}
		
		return msgBundle;
	}

	/**
	 * <p>Fetches a property from the default resource bundle.</p>
	 *
	 * <p>It is recomended to use the corresponding {@link #getProperty(String) getProperty} method,
	 * unless the requested property should not be changed after the application has been initialized.<br>
	 * Examples of such properties are the default locale and format patterns.</p>
	 *
	 * @param key The key identifying the property.
	 *
	 * @return The requested property.
	 */
	public static String getResource(String key) {
		return getResource(key, DEFAULT_BUNDLE);
	}

	/**
	 * <p>Fetches a property from the specified resource bundle.</p>
	 *
	 * <p>It is recomended to use the corresponding {@link #getProperty(String, String) getProperty} method,
	 * unless the requested property should not be changed after the application has been initialized.<br>
	 * Examples of such properties are the default locale and format patterns.</p>
	 *
	 * @param key          The key identifying the property.
	 * @param resourceFile The name of the resource bundle to use.
	 *
	 * @return The requested property.
	 */
	public static String getResource(String key, String resourceFile) {
		ResourceBundle res = ResourceBundle.getBundle(resourceFile);

		return res.getString(key).trim();
	}

	/**
	 * <p>Fetches a property from the default resource bundle.</p>
	 *
	 * <p>The {@code getProperty} methods can optionally check if the corresponding resource bundle
	 * has been changed and reload it, thus fetching the updated values each time.<br>
	 * The ability to check for changed resource bundles is controlled by the {@code checkModifiedProperties}
	 * property in the default resource bundle. If the {@code checkModifiedProperties} has a value other
	 * than {@code true} the check is skipped.</p>
	 *
	 * @param key The key identifying the property.
	 *
	 * @return The requested property.
	 */
	public static String getProperty(String key) throws CUSTException {
		return getProperty(key, DEFAULT_BUNDLE);
	}

	/**
	 * <p>Fetches a property from the specified resource bundle for the default application locale.</p>
	 *
	 * <p>The {@code getProperty} methods can optionally check if the corresponding resource bundle
	 * has been changed and reload it, thus fetching the updated values each time.<br>
	 * The ability to check for changed resource bundles is controlled by the {@code checkModifiedProperties}
	 * property in the default resource bundle. If the {@code checkModifiedProperties} has a value other
	 * than {@code true} the check is skipped.</p>
	 *
	 * @param key      The key identifying the property/message.
	 * @param propFile The name of the resource bundle to use.
	 *
	 * @return The requested property.
	 *
	 * @throws CUSTException
	 */
	public static String getProperty(String key, String propFile) throws CUSTException {
		return getProperty(key, propFile, null);
	}

	/**
	 * <p>Fetches a property from the specified resource bundle for the specified locale.</p>
	 *
	 * <p>The {@code getProperty} methods can optionally check if the corresponding resource bundle
	 * has been changed and reload it, thus fetching the updated values each time.<br>
	 * The ability to check for changed resource bundles is controlled by the {@code checkModifiedProperties}
	 * property in the default resource bundle. If the {@code checkModifiedProperties} has a value other
	 * than {@code true} the check is skipped.</p>
	 *
	 * @param key      The key identifying the property/message.
	 * @param propFile The name of the resource bundle to use.
	 * @param loc      The {@code Locale} for the requested property. If {@code null} the default application locale is used.
	 *
	 * @return The requested localized property.
	 *
	 * @throws CUSTException
	 */
	public static String getProperty(String key, String propFile, Locale loc) throws CUSTException {
		return getProperty(key, propFile, loc, false);
	}

	/**
	 * <p>Fetches a property for the specified locale from the specified XML resource bundle.<br>
	 * <i>Note:</i> A "XML resource bundle" is a XML properties file as described in the documentation
	 * of the {@link java.util.Properties} class.</p>
	 *
	 * <p>The {@code getProperty} methods can optionally check if the corresponding resource bundle
	 * has been changed and reload it, thus fetching the updated values each time.<br>
	 * The ability to check for changed resource bundles is controlled by the {@code checkModifiedProperties}
	 * property in the default resource bundle. If the {@code checkModifiedProperties} has a value other
	 * than {@code true} the check is skipped.</p>
	 *
	 * @param key      The key identifying the property.
	 * @param propFile The name of the XML resource bundle to use.
	 * @param loc      The {@code Locale} for the requested property. If {@code null} the default application locale is used.
	 *
	 * @return The requested localized property.
	 *
	 * @throws CUSTException
	 */
	public static String getPropertyXML(String key, String propFile, Locale loc) throws CUSTException {
	    return getProperty(key, propFile, loc, true);
	}

	/* private method that fetches a property from either a .properties or a .xml file */
	private static String getProperty(String key, String propFile, Locale loc, boolean isXML) throws CUSTException {
		Properties pr = null;

		if (loc == null) {
			loc = getDefaultLocale();
		}

		ResourceBundle res = ResourceBundle.getBundle(propFile, loc);
		String lang = res.getLocale().getLanguage();
		String fileName = propFile + (lang.equals("") ? "" : "_" + lang) + (isXML ? ".xml" : ".properties");
		if (!fileName.startsWith("/")) {
			fileName = "/" + fileName;
		}

		URL u = (new PropUtilsCust()).getClass().getResource(fileName);
		
		// if the properties file is inside a jar then we cannot use the File class -> the checkModifiedProperties flag is ignored
		if (u.getProtocol().equals("jar")) {
			InputStream is = (new PropUtilsCust()).getClass().getResourceAsStream(fileName);
			
		    if (bundles.containsKey(fileName)) {
			    TimedProperty tp = bundles.get(fileName);
			    pr = tp.bundle;
			}
			else {
			    pr = new Properties();
			    try {
			        if (isXML) {
			            pr.loadFromXML(is);
			        }
			        else {
			            pr.load(is);
			        }
			    }
			    catch (IOException e) {
			        throw new CUSTException(e.getMessage());
			    }
			    
				bundles.put(fileName, new TimedProperty(pr, 0L));
			}
		}
		else {
		    File f;
		    try {
		        f = new File(new URI(u.getProtocol(), u.getAuthority(), u.getPath(), null, null));
		    }
		    catch (URISyntaxException e) {
		         throw new CUSTException(e.getMessage());
		    }

		    if (bundles.containsKey(fileName)) {
		        TimedProperty tp = bundles.get(fileName);
		        if ("true".equals(com.workable.movie.app.utils.PropUtils.getResource("checkModifiedProperties")) && f.lastModified() > tp.lastModified) {
		            try {
		                if (isXML) {
		                    tp.bundle.loadFromXML(new FileInputStream(f));
		                }
		                else {
		                    tp.bundle.load(new FileInputStream(f));
		                }
		            }
		            catch (IOException e) {
		                 throw new CUSTException(e.getMessage());
		            }
		            tp.lastModified = f.lastModified();
		        }

		        pr = tp.bundle;
		    }
		    else {
		        pr = new Properties();
		        try {
		            if (isXML) {
		                pr.loadFromXML(new FileInputStream(f));
		            }
		            else {
		                pr.load(new FileInputStream(f));
		            }
		        }
		        catch (IOException e) {
		            throw new CUSTException(e.getMessage());
		        }
		        bundles.put(fileName, new TimedProperty(pr, f.lastModified()));
		    }
		}
		
		String value = pr.getProperty(key);
		if (value != null) {
			value = value.trim();
		}

		return value;
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the default message bundle for the default application locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key The key identifying the formating pattern.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key) throws CUSTException {
		return getLocalizedMsg(key, null, null, null);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the specified message bundle for the default application locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key     The key identifying the formating pattern.
	 * @param msgFile The name of the message bundle to use. If {@code null} the default message bundle is used.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, String msgFile) throws CUSTException {
		return getLocalizedMsg(key, msgFile, null, null);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the default message bundle for the specified locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key The key identifying the formating pattern.
	 * @param loc The {@code Locale} for the requested message. If {@code null} the default application locale is used.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, Locale loc) throws CUSTException {
		return getLocalizedMsg(key, null, loc, null);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the specified message bundle for the specified locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key     The key identifying the formating pattern.
	 * @param loc     The {@code Locale} for the requested message. If {@code null} the default application locale is used.
	 * @param msgFile The name of the message bundle to use. If {@code null} the default message bundle is used.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, String msgFile, Locale loc) throws CUSTException {
		return getLocalizedMsg(key, msgFile, loc, null);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the default message bundle for the default application locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key    The key identifying the formating pattern.
	 * @param params An array of arguments to be formated according to the specified pattern.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, Object[] params) throws CUSTException {
		return getLocalizedMsg(key, null, null, params);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the specified message bundle for the default application locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key     The key identifying the formating pattern.
	 * @param msgFile The name of the message bundle to use. If {@code null} the default message bundle is used.
	 * @param params  An array of arguments to be formated according to the specified pattern.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, String msgFile, Object[] params) throws CUSTException {
		return getLocalizedMsg(key, msgFile, null, params);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the default message bundle for the specified locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>For information regarding facilitating translation see {@link #getLocalizedMsg(String, String, Locale, Object[])}.</p>
	 *
	 * @param key The key identifying the formating pattern.
	 * @param loc The {@code Locale} for the requested message. If {@code null} the default application locale is used.
	 * @param params  An array of arguments to be formated according to the specified pattern.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, Locale loc, Object[] params) throws CUSTException {
		return getLocalizedMsg(key, null, loc, params);
	}

	/**
	 * <p>Fetches a localized (i18n) message string from the specified message bundle for the specified locale.</p>
	 *
	 * <p>The {@code getLocalizedMsg} methods use the {@code getProperty} methods in order to get the localized
	 * pattern (see {@link java.text.MessageFormat}) for the requested message.</p>
	 *
	 * <p>In order to facilitate the translation of an application use the optional properties {@code TranslationMode}
	 * and {@code ShowResourceIds}. If {@code TranslationMode = true} the returned message is enclosed inside curly braces
	 * ({@code {}}). If {@code ShowResourceIds} is also set to {@code true} the message is prepended with the
	 * corresponding {@code key}: "<code>{</code><i>{@code key}</i> {@code →} <i>{@code message}</i><code>}</code>"</p>
	 *
	 * @param key     The key identifying the formating pattern.
	 * @param loc     The {@code Locale} for the requested message. If {@code null} the default application locale is used.
	 * @param msgFile The name of the message bundle to use. If {@code null} the default message bundle is used.
	 * @param params  An array of arguments to be formated according to the specified pattern.
	 *
	 * @return The requested localized message.
	 *
	 * @throws CUSTException
	 */
	public static String getLocalizedMsg(String key, String msgFile, Locale loc, Object[] params) throws CUSTException {
		String msg = "";
		String bundle = (msgFile == null) ? DEFAULT_MESSAGE_BUNDLE : msgFile;

		if (loc == null) {
		    loc = getDefaultLocale();
		}

		if (params == null)  {
			try{
				msg = com.workable.movie.app.utils.PropUtils.getProperty(key, bundle, loc);
			}catch(Exception e){
				
			}
		}
		else {
			MessageFormat fmt = new MessageFormat("");
			fmt.setLocale(loc);
			try{
				fmt.applyPattern(com.workable.movie.app.utils.PropUtils.getProperty(key, bundle, loc));
			}catch(Exception e){
				
			}
			msg = fmt.format(params);
		}

		if (msg == null) {
			msg = "Message Key: \"" + key + "\" not found in bundle " + bundle + " for locale " + loc.getLanguage();

			System.err.print(msg);
		}

		if ("true".equals(com.workable.movie.app.utils.PropUtils.getResource("TranslationMode"))) {
			if ("true".equals(com.workable.movie.app.utils.PropUtils.getResource("ShowResourceIds"))) {
				msg = "{" + key + " → " + msg + "}";
			}
			else {
				msg = "{" + msg + "}";
			}
		}

		return msg;
	}

	/**
	 * <p>Fetches the default application locale.</p>
	 *
	 * <p>The default locale is determined by the {@code defaultLocale} property in the default resource bundle.<br>
	 * The value of the {@code defaultLocale} property must be a valid <b>ISO Language Code</b> as defined by ISO-639.<br>
	 * If this property is not set then the default locale is the greek locale as defined by {@code new Locale("el")}.</p>
	 *
	 * @return The default {@code Locale}.
	 *
	 * @see java.util.Locale
	 */
	public static Locale getDefaultLocale() {
		Locale loc = new Locale("el");

		try {
			String localeStr = com.workable.movie.app.utils.PropUtils.getResource("defaultLocale");

			if (!StringUtils.isBlank(localeStr)) {
				loc = getLocale(localeStr);
			}
		}
		catch (Exception ex) {
			;
		}

		return loc;
	}

	/**
	 * <p>Fetches the {@code Locale} which corresponds to the specified <b>ISO Language Code</b> as defined by ISO-639.</p>
	 * 
	 * @param localeStr A valid <b>ISO Language Code</b> as defined by ISO-639.
	 * 
	 * @return A {@code Locale} object.
	 * 
	 * @throws CUSTException when the specified {@code localeStr} is not a valid <b>ISO Language Code</b> as defined by ISO-639.
	 */
	public static Locale getLocale(String localeStr) throws CUSTException {
		String err = "\"" + localeStr + "\" is not a valid ISO-639 Language Code.";
		
		if (StringUtils.isBlank(localeStr)) {
		    throw new CUSTException(err);
		}
		
		Locale loc = null;
		String[] locStr = localeStr.split("_");
	    
	    switch (locStr.length) {
			case 1: {
				loc = new Locale(locStr[0]);
			}
			break;
	    
			case 2: {
				loc = new Locale(locStr[0], locStr[1]);
			}
			break;
	    
			case 3: {
				loc = new Locale(locStr[0], locStr[1], locStr[2]);
			}
			break;
			
			default: {
				throw new CUSTException(err);
			}
	    }
		
		return loc;
	}
	
	/**
	 * <p>Fetches the default application date format.</p>
	 *
	 * <p>The default date format is determined by the {@code defaultDateFormat} property in the default resource bundle.<br>
	 * If this property is not set then the default defaultDateFormat is the pattern "{@code dd/MM/yyyy}".</p>
	 *
	 * @return The default date format pattern.
	 *
	 * @see java.text.SimpleDateFormat
	 */
	public static String getDefaultDateFormat() {
		String fmt = "dd/MM/yyyy";

		try {
			fmt = com.workable.movie.app.utils.PropUtils.getResource("defaultDateFormat");
		}
		catch (Exception ex) {
			;
		}

		return fmt;
	}
	
	
	
}
