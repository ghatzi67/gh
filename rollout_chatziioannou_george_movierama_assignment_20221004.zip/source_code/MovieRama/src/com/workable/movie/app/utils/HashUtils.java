package com.workable.movie.app.utils;

import java.io.UnsupportedEncodingException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Includes utilities for hashing/encoding strings.
 */
public class HashUtils {
	/**
	 * Hashes the provided string using the MD5 algorithm.
	 *
	 * @param str A string.
	 *
	 * @return The hashed string (max 32 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 */
	public static String md5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		return hash(str, "md5");
	}

	/**
	 * Hashes the provided string using the SHA-1 algorithm.
	 *
	 * @param str A string.
	 *
	 * @return The hashed string (max 40 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 */
	public static String sha1(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		return sha(str, 128);
	}

	/**
	 * Hashes the provided string using the equivalent SHA algorithm for the specified {@code bitStrength}
	 *
	 * @param str         A string.
	 * @param bitStrength The required strength for the SHA algorithm in bits.<br>
	 *                    Supported values are: 128, 256, 384 and 512.<br>
	 *                    If an unsupported value is specified the default value of 128 is used instead.
	 *
	 * @return The hashed string (max 40 characters).
	 *
	 * @throws NoSuchAlgorithmException
	 */
	public static String sha(String str, int bitStrength) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		String algorithm = "SHA-1";

		switch (bitStrength) {
			case 256:
				algorithm = "SHA-256";
			break;

			case 384:
				algorithm = "SHA-384";
			break;

			case 512:
				algorithm = "SHA-512";
			break;

			default:
				algorithm = "SHA-1";
		}

		return hash(str, algorithm);
	}

	/**
	 * Hashes the provided string using the specified algorithm.
	 *
	 * @param str A string.
	 * @param algorithm The standard name of the digest algorithm.
	 *
	 * @return The hashed string.
	 *
	 * @throws NoSuchAlgorithmException
	 *
	 * @see java.security.MessageDigest
	 */
	public static String hash(String str, String algorithm) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md = MessageDigest.getInstance(algorithm);
		byte[] b = md.digest(str.getBytes("UTF-8"));
		String s = "";
		for (int i=0; i < b.length; i ++) {
			String highByte = Integer.toHexString(b[i] >>> 4 & 0xF);
			String lowByte = Integer.toHexString(b[i] & 0xF);
			s += highByte + lowByte;
		}
		return s;
	}
}
