package com.workable.movie.app.utils;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Login {
	private static Logger logger = Logger.getLogger(Login.class);
	private String surname = "";
	private String firstname = "";
	private String username = "";
	private String userpassword = "";
	private String userpasswordconf = "";
	private String useremail = "";
	
	public Login() {
	    PropertyConfigurator.configure( PropUtilsCust.getResource("LogPath") );
	}
	
	public String insertUser() throws Exception{
	    String sql = null;
	    Connection cn1 = null;
	    PreparedStatement pst = null;
		int ret = 1;
		String error = "";
		try {
			if(surname==null || "".equals(surname)){
				ret=3;
				Exception e = new Exception("The surname cannot ne empty!");
				throw e;
			}
//			surname = surname.replace("'", "''");
			
			if(firstname==null || "".equals(firstname)){
			    ret=3;
				Exception e = new Exception("The name cannot ne empty!");
				throw e;
			}
//		    firstname = firstname.replace("'", "''");
	
			if(username==null){
			    ret=3;
				Exception e = new Exception("The username cannot ne empty!");
				throw e;
			}
			
			if(username.length() < 6){
			    ret=3;
				Exception e = new Exception("The username should have at least 6 characters!");
				throw e;
			}
//		    username = username.replace("'", "''");
			
			if(userpassword==null || userpasswordconf==null){
			    ret=3;
				Exception e = new Exception("The password cannot ne empty!");
				throw e;
			}
			
			if(userpassword.length() < 8){
			    ret=3;
				Exception e = new Exception("The password should have at least 8 characters!");
				throw e;
			}
			
			if(!userpassword.equals(userpasswordconf)){
			    ret=3;
				Exception e = new Exception("Password confirmation failed!");
				throw e;
			}
//		    userpassword = userpassword.replace("'", "''");
			
		    if(useremail==null || "".equals(useremail)){
			    useremail = "";
			}
//		    useremail = useremail.replace("'", "''");
			
			if (username!=null && username.matches("(?s).*[\"()'<>{}\\[\\]\\\\#*;&%\\x00\\n\\r].*")){
				if (logger.isDebugEnabled()){
					logger.debug("username MATCHES  -> " + ret);
				}
			    ret=3;
				Exception e = new Exception("Illegal characters detected in the username!");
			    throw e;
			}
			
		    cn1 = new CUSTConnection().GetNewConn();
			sql = 
			"INSERT INTO APPUSER \n" + 
			"( \n" + 
			"WEB_USER, \n" + 
			"WEB_PASSWORD, \n" + 
			"WEB_LAST_ACCESS, \n" + 
			"WEB_SURNAME, \n" + 
			"WEB_NAME, \n" + 
			"WEB_ACCOUNT_STATUS, \n" + 
			"WEB_FULL_NAME, \n" + 
			"WEB_USER_EMAIL \n" + 
			") \n" + 
			"VALUES \n" + 
			"( \n" + 
			"?, \n" + 
		    "return_hash(?), \n" + 
			"NULL, \n" + 
			"?, \n" + 
			"?, \n" + 
			"1, \n" + 
			"? || ' ' || ?, \n" + 
			"? \n" + 
			")";
			
		    pst = cn1.prepareStatement(sql);
			pst.setString(1, username);
		    pst.setString(2, userpassword);
		    pst.setString(3, surname);
		    pst.setString(4, firstname);
		    pst.setString(5, surname);
		    pst.setString(6, firstname);
		    pst.setString(7, useremail);
		    pst.executeUpdate();
			
			//st.execute(sql);
			
		} catch (Exception ex) {
			if(ret==3){
				error = ex.getMessage();
			}else{
				error = "System error occured.";
			}
			logger.fatal(ex.getMessage(), ex);
		} finally {
			if (cn1 != null ) {
				cn1.close();
			}
			
		    if (pst != null ) {
		        pst.close();
		    }
		}
		return error;
	}
	
	public String getUserFullName() throws Exception{
		String sql = null;
		Connection cn1 = null;
		Statement st = null;
		ResultSet rs = null;
		String fullName = "";
		try {
		    if(username==null || "".equals(username)){
		        Exception e = new Exception("The username cannot be empty!");
		        throw e;
		    }
			
			cn1 = new CUSTConnection().GetNewConn();
			st = cn1.createStatement();
			sql = 
			"SELECT WEB_FULL_NAME FROM APPUSER WHERE WEB_USER='"+username+"'";
			rs = st.executeQuery(sql);
			if(rs.next()){
			    fullName = rs.getString("WEB_FULL_NAME");
			}
			
		} catch (Exception ex) {
			logger.fatal(ex.getMessage(), ex);
			throw ex;
		} finally {
			if (cn1 != null ) {
				cn1.close();
			}
			
			if (st != null ) {
				st.close();
			}
			
		    if (rs != null ) {
		        rs.close();
		    }
		}
		return fullName;
	}
	
	public int validateUser(javax.servlet.http.HttpServletRequest request) throws Exception{
		int ret = 1;
		String username = "";
		String userpassword = "";
	    Connection cn1 = null;
	    Statement st = null;
	    ResultSet rs = null;
	    String sql = null;
		try {
			username = request.getParameter("username");
		    userpassword = request.getParameter("userpassword");
			sql = "select 'X' from APPUSER where WEB_USER='"+username+"' and WEB_PASSWORD=return_hash('"+userpassword+"')";
		    cn1 = new CUSTConnection().GetNewConn();
		    st = cn1.createStatement();
			rs = st.executeQuery(sql);
			if(rs.next()){
				ret = 1;
				request.getSession().setAttribute("appuser", username);
			    request.getSession().setAttribute("sId", request.getSession().getId());
			}else{
				ret = 2;
			}
			if(ret==1){
				sql = "UPDATE APPUSER SET WEB_LAST_ACCESS=SYSDATE WHERE WEB_USER='"+username+"'";
				st.execute(sql);
			}
		} catch (Exception e) {
			logger.fatal(e.getMessage(), e);
		    ret = 2;
		} finally {
			if (cn1 != null ) {
				cn1.close();
			}
			
			if (st != null ) {
				st.close();
			}
			
		    if (rs != null ) {
		        rs.close();
		    }
		}
		return ret;
	}
	
	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getSurname() {
		return surname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpasswordconf(String userpasswordconf) {
		this.userpasswordconf = userpasswordconf;
	}

	public String getUserpasswordconf() {
		return userpasswordconf;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUseremail() {
		return useremail;
	}
}
