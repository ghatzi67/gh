package com.workable.movie.app.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;

import java.net.URL;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Vector;

import oracle.xml.parser.v2.*;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Includes utilities for XML.
 */
public class XMLUtils {
	/**
	 * Returns a string represantation of a XML node.
	 *
	 * @param n A XML node.
	 *
	 * @return The string represantation of the provided node.
	 *
	 * @throws CUSTException
	 */
	public static String xmlToString(Node n) throws CUSTException {
		String s;

		ByteArrayOutputStream out = new ByteArrayOutputStream();

		String encoding = "UTF-8";
		if (n instanceof Document) {
			encoding = ((XMLDocument) n).getEncoding();
		}
		else if (n.getOwnerDocument() != null) {
			encoding = ((XMLDocument) n.getOwnerDocument()).getEncoding();
		}

		try {
			((XMLNode) n).print(out);
			out.close();
			s = out.toString(encoding);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return s;
	}

	/**
	 * Returns a string represantation of a XML document.
	 *
	 * @param doc A XML document.
	 * @param prettyPrint If true the document is printed with indentation.
	 *
	 * @return The string represantation of the provided node.
	 *
	 * @throws CUSTException
	 */
	public static String xmlToString(XMLDocument doc, boolean prettyPrint) throws CUSTException {
		String s;

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		XMLPrintDriver pd = new XMLPrintDriver(out);
		pd.setFormatPrettyPrint(prettyPrint);

		String encoding = "UTF-8";
		encoding = doc.getEncoding();

		try {
			doc.print(pd);
			out.close();
			s = out.toString(encoding);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return s;
	}

	/**
	 * Parses a XML string to a {@code XMLDocument}.
	 *
	 * @param s A XML string.
	 *
	 * @return The parsed string as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseString(String s) throws CUSTException {
		DOMParser dp = new DOMParser();
		StringReader sr = new StringReader(s);

		try {
			dp.parse(sr);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}

	/**
	 * Parses a {@code URL} to a {@code XMLDocument}.
	 *
	 * @param url A {@code URL} to load the XML from.
	 *
	 * @return The parsed {@code URL} as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseURL(URL url) throws CUSTException {
		DOMParser dp = new DOMParser();

		try {
			dp.parse(url);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}

	/**
	 * Parses a url to a {@code XMLDocument}.
	 *
	 * @param url A url to load the XML from.
	 *
	 * @return The parsed url as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseURL(String url) throws CUSTException {
		DOMParser dp = new DOMParser();

		try {
			dp.parse(url);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}

	/**
	 * Parses a XML file to a {@code XMLDocument}.
	 *
	 * @param filePath The complete file path to load the XML from.
	 *
	 * @return The parsed file as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseFile(String filePath) throws CUSTException {
		DOMParser dp = new DOMParser();

		try {
			FileInputStream fs = new FileInputStream(filePath);
			dp.parse(fs);
			fs.close();
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}

	/**
	 * Parses a {@code File} to a {@code XMLDocument}.
	 *
	 * @param f A {@code File} to load the XML from.
	 *
	 * @return The parsed {@code File} as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseFile(File f) throws CUSTException {
		DOMParser dp = new DOMParser();

		try {
			FileInputStream fs = new FileInputStream(f);
			dp.parse(fs);
			fs.close();
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}

	/**
	 * Parses a file that resides in the application's classpath to a {@code XMLDocument}.
	 *
	 * @param resPath A path to an application resource file to load the XML from.
	 *
	 * @return The parsed application resource file as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument parseResource(String resPath) throws CUSTException {
		DOMParser dp = new DOMParser();

		if (!resPath.startsWith("/")) {
			resPath = "/" + resPath;
		}

		try {
			InputStream is = (new XMLUtils()).getClass().getResourceAsStream(resPath);
			dp.parse(is);
			is.close();
		}
		catch (NullPointerException e) {
			throw new CUSTException("Resource file: \"" + resPath + "\" not found", e);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}

		return dp.getDocument();
	}
	
	/**
	 * Parses a stream to a {@code XMLDocument}.
	 *
	 * @param is An input stream with the XML content.
	 *
	 * @return The parsed stream content as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
		public static XMLDocument parseStream(InputStream is) throws CUSTException {
			DOMParser dp = new DOMParser();

			try {
				dp.parse(is);
				is.close();
			}
			catch (Exception e) {
				throw new CUSTException(e);
			}

			return dp.getDocument();
		}


	/**
	 * Saves a {@code Document} to a file.
	 *
	 * @param d A {@code Document}.
	 * @param filePath The complete file path to save the document to.
	 *
	 * @throws CUSTException
	 */
	public static void saveDocument(Document d, String filePath) throws CUSTException {
		try {
			XMLDocument xd = (XMLDocument) d;
			FileOutputStream fs = new FileOutputStream(filePath);
			xd.print(fs, xd.getEncoding());
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Creates an element node with the specified name and a text child node with the specified content
	 * and appends it to the provided XML node.
	 *
	 * @param n     The {@code Node} to append the element to.
	 * @param name  The name of the element.
	 * @param value The content of the element's text child node.
	 *
	 * @return The created element node as an {@code Element} object.
	 */
	public static Element appendElement(Node n, String name, String value) {
		Document d = n.getOwnerDocument();
		if (d == null && n instanceof Document) {
			d = (Document) n;
		}

		Element e = d.createElement(name);
		Text t = d.createTextNode(value);
		e.appendChild(t);
		n.appendChild(e);

		return e;
	}

	/**
	 * Creates an element node with the specified name in the specified namespace and a text child node with the specified content
	 * and appends it to the provided XML node.
	 *
	 * @param n     The {@code Node} to append the element to.
	 * @param uri	The namespace the new elements belongs to.
	 * @param name  The name of the element.
	 * @param value The content of the element's text child node.
	 *
	 * @return The created element node as an {@code Element} object.
	 */
	public static Element appendElementNS(Node n, String uri, String name, String value) {
		Document d = n.getOwnerDocument();
		if (d == null && n instanceof Document) {
			d = (Document) n;
		}

		Element e = d.createElementNS(uri, name);
		Text t = d.createTextNode(value);
		e.appendChild(t);
		n.appendChild(e);

		return e;
	}

	/**
	 * Appends a XML document to the provided {@code Node}.
	 *
	 * @param n The {@code Node} to append the XML document to.
	 * @param d The {@code Document} to append.
	 */
	public static void importDocument(Node n, Document d) {
		Document owner = n.getOwnerDocument();
		if (owner == null && n instanceof Document) {
			owner = (Document) n;

			if (owner.getDocumentElement() != null) {
			    n = owner.getDocumentElement();
			}
		}

	    n.appendChild(owner.importNode(d.getDocumentElement(), true));
	}

	/**
	 * Appends all nodes of a {@code NodeList} to the provided {@code Node}.
	 *
	 * @param n     The {@code Node} to append the {@code NodeList} to.
	 * @param nodes The {@code NodeList} to append.
	 */
	public static void importNodeList(Node n, NodeList nodes) {
	    if (n instanceof Document) {
			n = ((Document) n).getDocumentElement();
		}

		for (int i = 0; i < nodes.getLength(); i ++) {
			Node tmp = n.getOwnerDocument().importNode(nodes.item(i), true);

			if (tmp instanceof Attr && n instanceof Element) {
				((Element) n).setAttributeNodeNS((Attr) tmp);
			}
			else {
				n.appendChild(tmp);
			}
		}
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocumentFragment} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocumentFragment transform(XMLDocument xml, XMLDocument xsl, HashMap<String, ?> params) throws CUSTException {
		XSLProcessor xp = new XSLProcessor();
		try {
			if (params != null) {
				Iterator<String> it = params.keySet().iterator();

				while (it.hasNext()) {
					String name = it.next();
					xp.setParam("", name, params.get(name));
				}
			}

			return xp.processXSL(xp.newXSLStylesheet(xsl), xml);
		}
		catch (XSLException e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML element.
	 *
	 * @param xml The {@code XMLElement} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocumentFragment} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocumentFragment transform(XMLElement xml, XMLDocument xsl, HashMap<String, ?> params) throws CUSTException {
		XSLProcessor xp = new XSLProcessor();
		try {
			if (params != null) {
				Iterator<String> it = params.keySet().iterator();

				while (it.hasNext()) {
					String name = it.next();
					xp.setParam("", name, params.get(name));
				}
			}

			return xp.processXSL(xp.newXSLStylesheet(xsl), xml);
		}
		catch (XSLException e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl A path to an application resource XSLT file.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocumentFragment} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocumentFragment transform(XMLDocument xml, String xsl, HashMap<String, ?> params) throws CUSTException {
		return transform(xml, parseResource(xsl), params);
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml A path to an application resource XML file to apply the transformation to.
	 * @param xsl A path to an application resource XSLT file.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocumentFragment} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocumentFragment transform(String xml, String xsl, HashMap<String, ?> params) throws CUSTException {
		return transform(parseResource(xml), parseResource(xsl), params);
	}

	/**
	 * Passes the provided parameters to a XSLT transformation, applies it to a XML document
	 * and writes the result to the specified {@code OutputStream}.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 * @param out The {@code OutputStream} to write the transforamtion result to.
	 *
	 * @throws CUSTException
	 */
	public static void transform(XMLDocument xml, XMLDocument xsl, HashMap<String, ?> params, OutputStream out) throws CUSTException {
		XSLProcessor xp = new XSLProcessor();
		try {
			if (params != null) {
				Iterator<String> it = params.keySet().iterator();

				while (it.hasNext()) {
					String name = it.next();
					xp.setParam("", name, params.get(name));
				}
			}

			xp.processXSL(xp.newXSLStylesheet(xsl), xml, out);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Passes the provided parameters to a XSLT transformation, applies it to a XML element
	 * and writes the result to the specified {@code OutputStream}.
	 *
	 * @param xml The {@code XMLElement} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 * @param out The {@code OutputStream} to write the transforamtion result to.
	 *
	 * @throws CUSTException
	 */
	public static void transform(XMLElement xml, XMLDocument xsl, HashMap<String, ?> params, OutputStream out) throws CUSTException {
		XSLProcessor xp = new XSLProcessor();
		try {
			if (params != null) {
				Iterator<String> it = params.keySet().iterator();

				while (it.hasNext()) {
					String name = it.next();
					xp.setParam("", name, params.get(name));
				}
			}

			xp.processXSL(xp.newXSLStylesheet(xsl), xml, out);
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a string.
	 *
	 * @throws CUSTException
	 */
	public static String transformToString(XMLDocument xml, XMLDocument xsl, HashMap<String, ?> params) throws CUSTException {
		XSLProcessor xp = new XSLProcessor();
		try {
			if (params != null) {
				Iterator<String> it = params.keySet().iterator();

				while (it.hasNext()) {
					String name = it.next();
					xp.setParam("", name, params.get(name));
				}
			}

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			XSLStylesheet xslt = xp.newXSLStylesheet(xsl);
			xp.processXSL(xslt, xml, out);
			out.close();

			return out.toString(xslt.getOutputEncoding());
		}
		catch (Exception e) {
			throw new CUSTException(e);
		}
	}

	/**
	 * Wrapps a {@code DocumentFragment} in a new {@code XMLDocument}.
	 *
	 * @param df A {@code DocumentFragment}.
	 *
	 * @return A {@code XMLDocument} with the provided {@code DocumentFragment} appended.
	 */
	public static XMLDocument fragmentToDoc(DocumentFragment df) {
		XMLDocument xd = new XMLDocument();
		xd.appendChild(xd.importNode(df, true));
		return xd;
	}

	/**
	 * Converts a {@code NodeList} to a {@code DocumentFragment}.
	 *
	 * @param nl A {@code NodeList}.
	 *
	 * @return A {@code DocumentFragment} or {@code null} if the {@code NodeList} is empty.
	 */
	public static DocumentFragment nodeListToFragment(NodeList nl) {
		if (nl.getLength() > 0) {
			DocumentFragment df = nl.item(0).getOwnerDocument().createDocumentFragment();

			for (int i = 0; i < nl.getLength(); i++) {
				df.appendChild(nl.item(i));
			}

			return df;
		}
		else {
			return null;
		}
	}

	/**
	 * Applies a XSLT transformation to a XML document.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument transformToDoc(XMLDocument xml, XMLDocument xsl) throws CUSTException {
		return fragmentToDoc(transform(xml, xsl, null));
	}

	/**
	 * Applies a XSLT transformation to a XML element.
	 *
	 * @param xml The {@code XMLElement} to apply the transformation to.
	 * @param xsl The XSLT to apply as a {@code XMLDocument}.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument transformToDoc(XMLElement xml, XMLDocument xsl) throws CUSTException {
		return fragmentToDoc(transform(xml, xsl, null));
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml The {@code XMLDocument} to apply the transformation to.
	 * @param xsl A path to an application resource XSLT file.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument transformToDoc(XMLDocument xml, String xsl, HashMap<String, ?> params) throws CUSTException {
		return fragmentToDoc(transform(xml, parseResource(xsl), params));
	}

	/**
	 * Passes the provided parameters to a XSLT transformation and applies it to a XML document.
	 *
	 * @param xml A path to an application resource XML file to apply the transformation to.
	 * @param xsl A path to an application resource XSLT file.
	 * @param params Optional parameters {@code HashMap} to pass to the XSLT.
	 *
	 * @return The result of the XSLT transformation as a {@code XMLDocument} object.
	 *
	 * @throws CUSTException
	 */
	public static XMLDocument transformToDoc(String xml, String xsl, HashMap<String, ?> params) throws CUSTException {
		return fragmentToDoc(transform(parseResource(xml), parseResource(xsl), params));
	}

	// TODO: Check xslt extensions for localization !!

	/**
	 * <p>Parses a XML document replacing all occurenses of &lt;pcs:message&gt; tags with i18n localized messages
	 * and all &lt;pcs:resource&gt; tags with application properties.</p>
	 *
	 * <p>For more information see {@link #getLocalizedXML(XMLNode,Locale)}.</p>
	 *
	 * @param inXML A {@code XMLDocument}.
	 * @param loc The {@code Locale} to use for the localized messages.
	 *
	 * @return The localized {@code XMLDocument}.
	 *
	 * @throws XSLException
	 * @throws CUSTException
	 */
	public static XMLDocument getLocalizedXML(XMLDocument inXML, Locale loc) throws XSLException, CUSTException {
		return (XMLDocument) getLocalizedXML((XMLNode) inXML.getDocumentElement(), loc).getOwnerDocument();
	}

	/**
	 * <p>Parses a XML node replacing all occurenses of <code>&lt;pcs:message&gt;</code> tags with i18n localized messages
	 * and all <code>&lt;pcs:resource&gt;</code> tags with application properties.</p>
	 *
	 * <p>For the <code>&lt;pcs:message&gt;</code> tags the method uses the
	 * {@link PropUtils#getLocalizedMsg(String,Locale,Object[]) getLocalizedMsg}
	 * method and for <code>&lt;pcs:resource&gt;</code> tags the
	 * {@link PropUtils#getProperty(String) getProperty} method of class {@code PropUtils}.
	 *
	 * <p>The {@code pcs:} namespace is identified by {@code http://www.pcs.gr/namespace}.</p>
	 *
	 * <p>The syntax for the <code>&lt;pcs:resource&gt;</code> tag is rather simple:
	 * <blockquote><code>&lt;pcs:resource key="<i>[resource key]</i>"/&gt;</code></blockquote>
	 * The mandatory attribute {@code key} is the property's identifier string (key) as defined in the default application
	 * resource bundle.</p>
	 *
	 * <p>The syntax for the <code>&lt;pcs:message&gt;</code> tag is a bit more complex:
	 * <blockquote><code>
	 * &lt;pcs:resource key="<i>[message key]</i>"&gt;<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;pcs:param&gt;<i>[parameter 1]</i>&lt;/pcs:param&gt;<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;pcs:param&gt;<i>[parameter 2]</i>&lt;/pcs:param&gt;<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;.<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;.<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;.<br>
	 * &lt;/pcs:resource&gt;
	 * </code></blockquote>
	 * The mandatory attribute {@code key} is the message's pattern identifier string (key) as defined in the default application
	 * message bundle.<br>
	 * The <code>&lt;pcs:message&gt;</code> tag may contain 0 or more <code>&lt;pcs:param&gt;</code> tags,
	 * which correspond to the pattern's arguments.<br>
	 * The <code>&lt;pcs:param&gt;</code> tag's content may be either a string or another <code>&lt;pcs:message&gt;</code> tag.</p>
	 *
	 * @param inXML A {@code XMLNode}.
	 * @param loc The {@code Locale} to use for the localized messages.
	 *
	 * @return The localized {@code XMLNode}.
	 *
	 * @throws XSLException
	 * @throws CUSTException
	 */
	public static XMLNode getLocalizedXML(XMLNode inXML, Locale loc) throws XSLException, CUSTException {
		XMLElement e = (XMLElement) inXML.getOwnerDocument().createElementNS("http://www.pcs.gr/namespace", "pcs:message");
		XMLElement x = (XMLElement) inXML.getOwnerDocument().createElementNS("http://www.w3.org/1999/XSL/Transform", "xsl:attribute");

		XMLNode message = null;
		while ((message = (XMLNode) inXML.selectSingleNode("//pcs:message", e)) != null) {
			String msg = getLocalizedMessage(message, loc);

			if (message.selectSingleNode("ancestor::xsl:attribute", x) != null) {
				XMLNode text = (XMLNode) message.getOwnerDocument().createTextNode(getLocalizedMessage(message, loc));
				message.getParentNode().replaceChild(text, message);
			}
			else {
				try {
					// This code assures that any HTML tags inside the messages are propertly appended to the resulting document.
					XMLDocument msgXML = parseString("<msg>" + msg + "</msg>");
					XMLNodeList nl = (XMLNodeList) msgXML.getDocumentElement().getChildNodes();
					XMLDocumentFragment df = (XMLDocumentFragment) message.getOwnerDocument().createDocumentFragment();

					for (int i = 0; i < nl.getLength(); i++) {
						df.appendChild(message.getOwnerDocument().importNode(nl.item(i), true));
					}

					message.getParentNode().replaceChild(df, message);
				}
				catch (Exception ex) {
					XMLNode text = (XMLNode) message.getOwnerDocument().createTextNode(getLocalizedMessage(message, loc));
					message.getParentNode().replaceChild(text, message);
				}
			}
		}

		XMLNode resource = null;
		while ((resource = (XMLNode) inXML.selectSingleNode("//pcs:resource", e)) != null) {
			String msg = PropUtils.getProperty(resource.valueOf("@key"));

			if (resource.selectSingleNode("ancestor::xsl:attribute", x) != null) {
				XMLNode text = (XMLNode) resource.getOwnerDocument().createTextNode(msg);
				resource.getParentNode().replaceChild(text, resource);
			}
			else {
				try {
				    // This code assures that any HTML tags inside the properties are propertly appended to the resulting document.
					XMLDocument msgXML = parseString("<msg>" + msg + "</msg>");
					XMLNodeList nl = (XMLNodeList) msgXML.getDocumentElement().getChildNodes();
					XMLDocumentFragment df = (XMLDocumentFragment) resource.getOwnerDocument().createDocumentFragment();

					for (int i = 0; i < nl.getLength(); i++) {
						df.appendChild(resource.getOwnerDocument().importNode(nl.item(i), true));
					}

					resource.getParentNode().replaceChild(df, message);
				}
				catch (Exception ex) {
					XMLNode text = (XMLNode) resource.getOwnerDocument().createTextNode(msg);
					resource.getParentNode().replaceChild(text, resource);
				}
			}
		}

		return inXML;
	}

	/* Translates a <pcs:message> tag to the corresponding localized message. */
	private static String getLocalizedMessage(XMLNode message, Locale loc) throws XSLException, CUSTException {
		XMLElement e = (XMLElement) message.getOwnerDocument().createElementNS("http://www.pcs.gr/namespace", "pcs:message");
		String key = message.valueOf("@key");
		Object[] params = null;
		if (message.selectSingleNode("pcs:param", e) != null) {
			Vector v = new Vector();

			XMLNodeList parameters = (XMLNodeList) message.selectNodes("pcs:param", e);
			for (int j = 0; j < parameters.getLength(); j++) {
				XMLNode param = (XMLNode) parameters.item(j);
				if (param.selectSingleNode("pcs:message", e) != null) {
					XMLNodeList messages = (XMLNodeList) param.selectNodes("pcs:message", e);
					for (int i = 0; i < messages.getLength(); i++) {
						v.add(getLocalizedMessage((XMLNode) messages.item(i), loc));
					}
				}
				else {
					v.add(param.valueOf("."));
				}
			}

			params = v.toArray();
		}

		return PropUtils.getLocalizedMsg(key, loc, params);
	}

	/**
	 * Gets the XMLParser version
	 *
	 * @return The XMLParser version
	 */
	public static String getXMLParserVersion() {
		return XMLParser.getReleaseVersion();
	}

	/**
	 * Gets the XMLParser (XDK) location
	 *
	 * @return The XMLParser location
	 */
	public static String getXMLParserLocation() {
		return ClassUtils.getClassLocation(XMLParser.class);
	}
}
